# UpEye - Activity & Pattern Tracking Application

A comprehensive web application for tracking daily activities and discovering behavioral patterns using Supabase as a backend database.

## 🚀 Quick Start

### Option 1: Local Development (Recommended for coding)
To avoid browser storage warnings during development:

1. **Install Node.js** (if not already installed)
2. **Open terminal** in project directory
3. **Run local server:**
   ```bash
   npm run dev
   ```
4. **Open your browser** to: `http://localhost:3000`

### Option 2: GitHub Pages (Recommended for production)
Deploy once and get a live HTTPS site with no storage warnings:

1. **Create GitHub repository**
2. **Push your code** - Automatic deployment via GitHub Actions
3. **Visit live site** - At `https://yourusername.github.io/upeye`

### Option 3: Direct File Opening
You can open `index.html` directly, but may see browser storage warnings.

## 📋 Features

- ✅ **User Management** - Create and select users
- ✅ **Calendar View** - Compact, professional activity calendar
- ✅ **Activity Tracking** - Add activities with time tracking
- ✅ **Health Metrics** - Generate and view health data
- ✅ **Pattern Analysis** - Discover behavioral patterns
- ✅ **Responsive Design** - Works on all devices

## � Deployment

### GitHub Pages (Recommended)

#### Automatic Deployment:
1. **Create repository** on GitHub
2. **Push your code** - Automatic deployment via Actions
3. **Live at** - `https://yourusername.github.io/upeye`

#### Benefits:
- ✅ **HTTPS by default** - No storage warnings
- ✅ **Free hosting** - No server costs
- ✅ **Global CDN** - Fast loading worldwide
- ✅ **SSL certificate** - Automatic security

#### Manual Steps:
```bash
# 1. Create GitHub repository
git init
git add .
git commit -m "Initial UpEye deployment"

# 2. Add remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/upeye.git

# 3. Push to GitHub (triggers automatic deployment)
git push -u origin main
```

### Local Development Server

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Or start production server
npm start
```

## 🎯 Usage

1. **Create User** - Add a new user account
2. **Select User** - Choose existing user to work with
3. **Navigate Calendar** - Click any day to view activities
4. **Add Activities** - Track daily activities with scores
5. **Generate Health Metrics** - Simulate health data generation
6. **View Patterns** - Analyze behavioral trends

## 🛠️ Development

### File Structure
```
upeye/
├── index.html          # Main application file
├── style.css           # Styling and design
├── app.js              # Application logic
├── config.js           # Supabase configuration
├── package.json         # Dependencies and scripts
├── .github/workflows/  # GitHub Actions deployment
├── .gitignore          # Git ignore rules
├── DEPLOYMENT.md       # Deployment guide
└── README.md           # This file
```

### Browser Compatibility

- ✅ **Chrome/Edge** - Full support
- ✅ **Firefox** - Full support  
- ✅ **Safari** - Full support
- ⚠️ **Local files** - May show storage warnings (use server or GitHub Pages)

## 🐛 Troubleshooting

### Storage Warnings
If you see "Tracking Prevention blocked access to storage":
- **Solution 1:** Deploy to GitHub Pages (recommended)
- **Solution 2:** Use local server (`npm run dev`)
- **Solution 3:** Adjust browser privacy settings

### Navigation Issues
If back buttons don't work:
- Refresh the page
- Check browser console for errors
- Ensure all files are loaded correctly

### Database Connection
If Supabase connection fails:
- Verify URL and key in `config.js`
- Check internet connection
- Ensure Supabase project is active
- Add your GitHub Pages URL to Supabase allowed origins

### Deployment Issues
If GitHub Pages doesn't update:
- Check Actions tab for deployment status
- Wait 5-10 minutes for changes to propagate
- Force rebuild in repository Settings → Pages

## 📱 Features

### Activity Tracking
- Time-based activity logging
- Productivity and satisfaction scoring
- Health metrics integration
- Chronological ordering

### Pattern Analysis
- Frequency tracking
- Time-based pattern detection
- Visual chart representations
- Comprehensive statistics

### User Interface
- Modern glass morphism design
- Responsive layout
- Smooth animations
- Professional color scheme

## 🌐 Production vs Development

| Feature | Local Development | GitHub Pages |
|----------|-------------------|---------------|
| Storage Warnings | ✅ Yes | ❌ No |
| HTTPS | ❌ No | ✅ Yes |
| URL | http://localhost:3000 | https://username.github.io |
| Setup Required | npm run dev | git push |
| Supabase Auth | ⚠️ May warn | ✅ Perfect |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

---

**🎉 Ready to deploy?** Check out [DEPLOYMENT.md](./DEPLOYMENT.md) for step-by-step instructions!
