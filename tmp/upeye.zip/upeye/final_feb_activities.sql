-- =================================
-- 5 ACTIVITIES PER DAY FOR ALL FEBRUARY (FINAL VERSION)
-- =================================

-- Generate all dates in February 2026
WITH feb_dates AS (
    SELECT generate_series(
        '2026-02-01'::date, 
        '2026-02-28'::date, 
        '1 day'::interval
    )::date as activity_date
),
-- Generate random activities for each day
random_activities AS (
    SELECT 
        d.activity_date,
        u.user_id,
        -- Random activity from 10 common types
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as activity_name,
        -- Random start hour between 6-22 (safe range)
        (FLOOR(RANDOM() * 16) + 6)::text || ':00:00'::time as start_time,
        -- Random duration 1-3 hours, ensure end time <= 23:59
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 3) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time
        END as end_time,
        -- Random scores between 1-10
        FLOOR(RANDOM() * 10 + 1) as productivity_score,
        FLOOR(RANDOM() * 10 + 1) as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
),
-- Create 5 activities per day
multi_activities AS (
    SELECT activity_date, user_id, activity_name, start_time, end_time, productivity_score, satisfaction_score
    FROM random_activities
    
    UNION ALL
    
    SELECT 
        activity_date, 
        user_id, 
        activity_name || ' - Task 2' as activity_name,
        -- Add 1-2 hours, ensure valid time
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 2) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 2)::text || ':00:00')::time
        END as start_time,
        -- Add 1-3 hours duration, ensure valid end time
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 3) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time
        END as end_time,
        GREATEST(productivity_score - FLOOR(RANDOM() * 3), 1) as productivity_score,
        GREATEST(satisfaction_score - FLOOR(RANDOM() * 2), 1) as satisfaction_score
    FROM random_activities
    
    UNION ALL
    
    SELECT 
        activity_date, 
        user_id, 
        activity_name || ' - Task 3' as activity_name,
        -- Add 1-2 hours, ensure valid time
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 2) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 2)::text || ':00:00')::time
        END as start_time,
        -- Add 1-3 hours duration, ensure valid end time
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 3) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time
        END as end_time,
        GREATEST(productivity_score - FLOOR(RANDOM() * 3), 1) as productivity_score,
        LEAST(satisfaction_score + FLOOR(RANDOM() * 2), 10) as satisfaction_score
    FROM random_activities
    
    UNION ALL
    
    SELECT 
        activity_date, 
        user_id, 
        activity_name || ' - Task 4' as activity_name,
        -- Add 1-2 hours, ensure valid time
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 2) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 2)::text || ':00:00')::time
        END as start_time,
        -- Add 1-3 hours duration, ensure valid end time
        CASE 
            WHEN (FLOOR(RANDOM() * 16) + 6 + 3) > 22 THEN '22:00:00'::time
            ELSE ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time
        END as end_time,
        GREATEST(productivity_score - FLOOR(RANDOM() * 3), 1) as productivity_score,
        LEAST(satisfaction_score + FLOOR(RANDOM() * 2), 10) as satisfaction_score
    FROM random_activities
    
    UNION ALL
    
    SELECT 
        activity_date, 
        user_id, 
        'Break Time' as activity_name,
        '14:00:00'::time as start_time,
        '14:30:00'::time as end_time,
        5 as productivity_score,
        8 as satisfaction_score
    FROM random_activities
)
-- Insert all days first
INSERT INTO days (user_id, activity_date)
SELECT DISTINCT user_id, activity_date 
FROM multi_activities
ON CONFLICT (user_id, activity_date) DO NOTHING;

-- Insert all activities (5 per day = 140 total)
INSERT INTO activities (day_id, activity_name, start_time, end_time, productivity_score, satisfaction_score)
SELECT 
    d.day_id,
    ma.activity_name,
    ma.start_time,
    ma.end_time,
    ma.productivity_score,
    ma.satisfaction_score
FROM multi_activities ma
JOIN days d ON ma.activity_date = d.activity_date AND ma.user_id = d.user_id;

-- Show summary of what was created
SELECT 
    d.activity_date,
    COUNT(a.activity_id) as activity_count,
    STRING_AGG(DISTINCT a.activity_name, ', ' ORDER BY a.activity_name) as unique_activities
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.activity_date
ORDER BY d.activity_date;

-- Total count verification
SELECT 
    COUNT(*) as total_activities,
    COUNT(DISTINCT activity_name) as unique_activity_types,
    COUNT(DISTINCT d.activity_date) as days_with_activities
FROM activities a
JOIN days d ON a.day_id = d.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28';
