-- =================================
-- CHECK IF SEQUENTIAL PATTERN SQL EXISTS
-- =================================

-- Look for any existing pattern analysis queries
SELECT 
    table_name,
    column_name,
    data_type
FROM information_schema.columns 
WHERE table_name LIKE '%pattern%' 
AND table_schema = 'public'
ORDER BY table_name, ordinal_position;

-- Check if there are any stored procedures or functions for patterns
SELECT 
    routine_name,
    routine_type,
    routine_definition
FROM information_schema.routines 
WHERE routine_schema = 'public'
AND (routine_name LIKE '%pattern%' OR routine_name LIKE '%sequence%');
