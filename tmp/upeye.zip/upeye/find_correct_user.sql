-- =================================
-- FIND WHICH USER HAS THE FEBRUARY ACTIVITIES
-- =================================

-- Find all users who have activities in February 2026
SELECT DISTINCT
    d.user_id,
    u.username,
    COUNT(a.activity_id) as total_activities,
    COUNT(DISTINCT d.activity_date) as days_with_activities
FROM days d
JOIN activities a ON d.day_id = a.day_id
JOIN users u ON d.user_id = u.user_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.user_id, u.username
ORDER BY total_activities DESC;

-- Show sample February dates with activities
SELECT 
    d.user_id,
    d.activity_date,
    COUNT(a.activity_id) as activity_count
FROM days d
JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.user_id, d.activity_date
ORDER BY d.activity_date
LIMIT 10;
