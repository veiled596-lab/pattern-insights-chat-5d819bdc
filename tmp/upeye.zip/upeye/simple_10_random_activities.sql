-- =================================
-- SIMPLE: 10 RANDOM ACTIVITIES FOR FEBRUARY TRIAL
-- =================================

-- Insert 10 random activities across different days in February
WITH random_dates AS (
    SELECT generate_series(
        '2026-02-01'::date, 
        '2026-02-28'::date, 
        '1 day'::interval
    )::date as activity_date
ORDER BY RANDOM()
LIMIT 10
),
random_activities AS (
    SELECT 
        d.activity_date,
        u.user_id,
        -- Random activity names from common activities
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as activity_name,
        -- Random time between 6:00 and 22:00
        (EXTRACT(HOUR FROM '06:00:00'::time) + FLOOR(RANDOM() * 16)::interval)::time as start_time,
        (EXTRACT(HOUR FROM '06:00:00'::time) + FLOOR(RANDOM() * 16)::interval + '1 hour'::interval)::time as end_time,
        -- Random scores between 3-10
        FLOOR(RANDOM() * 8 + 3) as productivity_score,
        FLOOR(RANDOM() * 8 + 3) as satisfaction_score
    FROM random_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
)
-- Insert days first
INSERT INTO days (user_id, activity_date)
SELECT DISTINCT user_id, activity_date 
FROM random_activities
ON CONFLICT (user_id, activity_date) DO NOTHING;

-- Insert the 10 activities
INSERT INTO activities (day_id, activity_name, start_time, end_time, productivity_score, satisfaction_score)
SELECT 
    d.day_id,
    ra.activity_name,
    ra.start_time,
    ra.end_time,
    ra.productivity_score,
    ra.satisfaction_score
FROM random_activities ra
JOIN days d ON ra.activity_date = d.activity_date AND ra.user_id = d.user_id;

-- Show what was inserted
SELECT 
    a.activity_name,
    a.start_time,
    a.end_time,
    a.productivity_score,
    a.satisfaction_score,
    d.activity_date
FROM activities a
JOIN days d ON a.day_id = d.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
ORDER BY d.activity_date, a.start_time;
