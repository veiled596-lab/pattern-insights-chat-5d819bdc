// =================================
// UpEye - Main Application Logic
// Educational Comments for Learning
// =================================

// Global State Management
const AppState = {
    currentUser: null,
    currentView: 'home',
    users: [],
    currentDays: [],
    currentActivities: [],
    currentMonth: new Date().getMonth(),
    currentYear: new Date().getFullYear(),
    currentPatterns: [],
    patternView: 'log' // 'log' or 'results'
};

// =================================
// UTILITY FUNCTIONS
// =================================

/**
 * Show a status message to the user
 * @param {string} message - The message to display
 * @param {string} type - 'success', 'error', or 'info'
 * @param {number} duration - How long to show the message (ms)
 */
function showStatusMessage(message, type = 'info', duration = 3000) {
    const statusDiv = document.getElementById('status-message');
    statusDiv.textContent = message;
    statusDiv.className = `status-message ${type}`;
    
    // Remove hidden class to show the message
    statusDiv.classList.remove('hidden');
    
    // Auto-hide after duration
    setTimeout(() => {
        statusDiv.classList.add('hidden');
    }, duration);
}

/**
 * Switch between different views in the application
 * @param {string} viewName - The view to show ('home', 'user-selection', 'user-creation')
 */
/**
 * Switch between different views in the application
 * @param {string} viewName - The view to show ('home', 'user-selection', 'user-creation', 'calendar', 'activity-details', 'patterns')
 */
async function switchView(viewName) {
    console.log('🔄 Switching to view:', viewName);
    
    // Hide all views
    document.querySelectorAll('.view').forEach(view => {
        view.classList.add('hidden');
    });
    
    // Show the requested view
    const targetView = document.getElementById(`${viewName}-view`);
    console.log('🔍 Looking for element:', `${viewName}-view`);
    console.log('🔍 Found target view:', targetView);
    
    if (targetView) {
        targetView.classList.remove('hidden');
        AppState.currentView = viewName;
        console.log('✅ Successfully switched to view:', viewName);
        
        // If switching to calendar view, automatically load today's activities
        if (viewName === 'calendar' && AppState.currentUser) {
            console.log('📅 Switching to calendar, loading today\'s activities...');
            const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
            const todayDayData = AppState.currentDays.find(d => d.activity_date === today);
            
            if (todayDayData) {
                console.log('🎯 Loading activities for today:', today);
                await loadActivitiesForDay(todayDayData.day_id);
                updateCalendarDisplay(); // Refresh calendar to show activity indicators
            }
        }
    } else {
        console.error('❌ View not found:', viewName);
        console.log('🔍 Available views:', document.querySelectorAll('.view'));
    }
}

// =================================
// USER MANAGEMENT FUNCTIONS
// =================================

/**
 * Load all users from the database
 * This function demonstrates how to fetch data from Supabase
 */
async function loadUsers() {
    try {
        console.log('🔄 Loading users from database...');
        
        // Supabase query to get all users
        // Only select the columns that actually exist in the users table
        const { data, error } = await window.supabaseClient
            .from('users')
            .select('user_id, username')
            .order('user_id', { ascending: false });
        
        if (error) {
            throw error;
        }
        
        console.log('✅ Users loaded successfully:', data);
        AppState.users = data || [];
        return AppState.users;
        
    } catch (error) {
        console.error('❌ Error loading users:', error);
        showStatusMessage('Failed to load users. Please try again.', 'error');
        return [];
    }
}

/**
 * Display users in a grid format
 * This function shows how to dynamically create HTML elements
 */
function displayUsers() {
    const usersList = document.getElementById('users-list');
    
    if (AppState.users.length === 0) {
        usersList.innerHTML = `
            <div class="no-users">
                <p>No users found. Create your first user!</p>
            </div>
        `;
        return;
    }
    
    // Create user cards dynamically
    usersList.innerHTML = AppState.users.map(user => `
        <div class="user-card" onclick="selectUser('${user.user_id}')">
            <h3>${user.username}</h3>
            <p><small>User ID: ${user.user_id}</small></p>
        </div>
    `).join('');
}

/**
 * Handle user selection
 * @param {string} userId - The ID of the selected user
 */
async function selectUser(userId) {
    try {
        console.log('👤 Selecting user:', userId);
        
        // Find the user in our state
        const user = AppState.users.find(u => u.user_id === userId);
        if (!user) {
            throw new Error('User not found');
        }
        
        AppState.currentUser = user;
        showStatusMessage(`Welcome back, ${user.username}!`, 'success');
        
        // Load days for this user
        await loadDaysForUser(userId);
        
        // Navigate to days table view
        await switchView('days-table');
        
    } catch (error) {
        console.error('❌ Error selecting user:', error);
        showStatusMessage('Failed to select user. Please try again.', 'error');
    }
}

/**
 * Create a new user in the database
 * This function demonstrates how to insert data into Supabase
 * @param {Object} userData - The user data to insert
 */
async function createUser(userData) {
    try {
        console.log('👤 Creating new user:', userData);
        
        // Insert new user into the database
        // Supabase will AUTOMATICALLY generate a random UUID for user_id
        // We don't need to provide user_id - Supabase creates it for us!
        const { data, error } = await window.supabaseClient
            .from('users')
            .insert([
                {
                    username: userData.username
                    // user_id is auto-generated by Supabase (gen_random_uuid())
                }
            ])
            .select()
            .single(); // .single() returns the inserted record
        
        if (error) {
            throw error;
        }
        
        console.log('✅ User created successfully:', data);
        console.log('🎯 Auto-generated user_id:', data.user_id);
        showStatusMessage(`User "${data.username}" created with ID: ${data.user_id}`, 'success');
        
        // Add the new user to our local state
        AppState.users.unshift(data);
        
        // Return to home page after a short delay
        setTimeout(async () => {
            await switchView('home');
        }, 2000);
        
        return data;
        
    } catch (error) {
        console.error('❌ Error creating user:', error);
        showStatusMessage(error.message || 'Failed to create user. Please try again.', 'error');
        return null;
    }
}

// =================================
// CALENDAR FUNCTIONS
// =================================

/**
 * Generate calendar HTML for current month
 * This function demonstrates how to create a calendar grid
 */
function generateCalendar() {
    const firstDay = new Date(AppState.currentYear, AppState.currentMonth, 1).getDay();
    const daysInMonth = new Date(AppState.currentYear, AppState.currentMonth + 1, 0).getDate();
    const today = new Date();
    const isCurrentMonth = today.getMonth() === AppState.currentMonth && today.getFullYear() === AppState.currentYear;
    
    let calendarHTML = '';
    let dayCounter = 1;
    
    // Add empty cells for days before month starts
    for (let i = 0; i < firstDay; i++) {
        calendarHTML += '<div class="calendar-day empty"></div>';
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const currentDate = new Date(AppState.currentYear, AppState.currentMonth, day);
        const dateString = currentDate.toISOString().split('T')[0];
        const isToday = currentDate.toDateString() === today.toDateString();
        
        // Check if day exists and has activities loaded
        const dayData = AppState.currentDays.find(d => d.activity_date === dateString);
        const hasActivities = dayData && dayData.activities && dayData.activities.length > 0;
        const activityCount = hasActivities ? dayData.activities.length : 0;
        
        console.log(`🔍 Calendar day ${dateString}: hasActivities=${hasActivities}, count=${activityCount}`);
        
        let dayClasses = 'calendar-day';
        
        if (isToday) {
            dayClasses += ' today';
        }
        
        if (hasActivities) {
            dayClasses += ' has-activity';
        }
        
        calendarHTML += `
            <div class="${dayClasses}" onclick="selectCalendarDay('${dateString}')">
                <div class="day-number">${day}</div>
                ${hasActivities ? `<div class="activity-indicator">${activityCount} activities</div>` : ''}
            </div>
        `;
    }
    
    // Add empty cells to complete the grid
    const totalCells = firstDay + daysInMonth;
    const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
    
    for (let i = 0; i < remainingCells; i++) {
        calendarHTML += '<div class="calendar-day empty"></div>';
    }
    
    return calendarHTML;
}

/**
 * Update calendar display
 * This function updates the calendar HTML and month/year display
 */
function updateCalendarDisplay() {
    const calendarGrid = document.getElementById('calendar-grid');
    const monthYearDisplay = document.getElementById('calendar-month-year');
    
    if (calendarGrid) {
        calendarGrid.innerHTML = generateCalendar();
    }
    
    if (monthYearDisplay) {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];
        monthYearDisplay.textContent = `${monthNames[AppState.currentMonth]} ${AppState.currentYear}`;
    }
}

/**
 * Navigate to previous month
 */
function previousMonth() {
    AppState.currentMonth--;
    if (AppState.currentMonth < 0) {
        AppState.currentMonth = 11;
        AppState.currentYear--;
    }
    updateCalendarDisplay();
}

/**
 * Navigate to next month
 */
function nextMonth() {
    AppState.currentMonth++;
    if (AppState.currentMonth > 11) {
        AppState.currentMonth = 0;
        AppState.currentYear++;
    }
    updateCalendarDisplay();
}

/**
 * Go to current month
 */
function goToCurrentMonth() {
    const today = new Date();
    AppState.currentMonth = today.getMonth();
    AppState.currentYear = today.getFullYear();
    updateCalendarDisplay();
}

/**
 * Handle calendar day selection
 * @param {string} dateString - The selected date in YYYY-MM-DD format
 */
async function selectCalendarDay(dateString) {
    console.log('📅 Selected calendar day:', dateString);
    console.log('🔍 Current days in state:', AppState.currentDays.length);
    console.log('🔍 Current days:', AppState.currentDays.map(d => ({ date: d.activity_date, activities: d.activities?.length || 0 })));
    
    // Always allow clicking any day - create day if it doesn't exist
    let dayData = AppState.currentDays.find(d => d.activity_date === dateString);
    console.log('🔍 Found day data:', dayData ? { 
        date: dayData.activity_date, 
        dayId: dayData.day_id,
        activitiesCount: dayData.activities?.length || 0,
        activities: dayData.activities?.map(a => a.activity_name) || []
    } : 'Not found');
    
    if (!dayData) {
        // Day doesn't exist - create it first
        console.log('📅 Creating new day for date:', dateString);
        const { data, error } = await window.supabaseClient
            .from('days')
            .insert([
                {
                    user_id: AppState.currentUser.user_id,
                    activity_date: dateString
                }
            ])
            .select()
            .single();
        
        if (error) {
            console.error('Error creating day:', error);
            showStatusMessage('Failed to create day. Please try again.', 'error');
            return;
        }
        
        console.log('✅ New day created:', data);
        dayData = data;
        
        // Add to our state
        AppState.currentDays.unshift(data);
        AppState.currentDays.sort((a, b) => new Date(b.activity_date) - new Date(a.activity_date));
    }
    
    // Use pre-loaded activities instead of reloading
    if (dayData && dayData.activities && dayData.activities.length > 0) {
        console.log('🎯 Using pre-loaded activities for day:', dateString);
        console.log('🎯 Activities found:', dayData.activities.length);
        console.log('🎯 Activity names:', dayData.activities.map(a => a.activity_name));
        AppState.currentActivities = dayData.activities;
        displayActivitiesGrid();
    } else {
        console.log('🔍 No pre-loaded activities, loading from database...');
        console.log('🔍 Day data check:', { 
            hasDayData: !!dayData, 
            hasActivities: !!(dayData?.activities), 
            activitiesLength: dayData?.activities?.length || 0 
        });
        await loadActivitiesForDay(dayData.day_id);
    }
    
    // Update activity date in header
    const activityDateSpan = document.getElementById('activity-date');
    if (activityDateSpan) {
        const formattedDate = new Date(dateString).toLocaleDateString();
        activityDateSpan.textContent = formattedDate;
    }
    
    // Switch to activity details view
    await switchView('activity-details');
}

/**
 * Display days in calendar format (updated from table)
 * This function now updates the calendar instead of a table
 */
function displayDaysTable() {
    // Update current user name in header
    const userNameSpan = document.getElementById('current-user-name');
    if (userNameSpan && AppState.currentUser) {
        userNameSpan.textContent = AppState.currentUser.username;
    }
    
    // Update calendar display
    updateCalendarDisplay();
    
    // Show message if no days
    if (AppState.currentDays.length === 0) {
        showStatusMessage('No days found. Start by adding activities!', 'info');
    }
}

/**
 * Show add activity form (placeholder for future implementation)
 */
function showAddActivityForm() {
    console.log('➕ Opening add activity form');
    
    // Get current day ID for the activity
    const currentDayId = AppState.currentDays.length > 0 
        ? AppState.currentDays[0].day_id 
        : null;
    
    if (!currentDayId) {
        showStatusMessage('Please select a day first!', 'error');
        return;
    }
    
    // Show the modal
    const modal = document.getElementById('activity-modal');
    if (modal) {
        modal.classList.add('active');
        modal.classList.remove('hidden');
        
        // Reset form
        const form = document.getElementById('activity-creation-form');
        if (form) {
            form.reset();
        }
        
        showStatusMessage('Activity form opened! Fill in the details and submit.', 'info');
    }
}

/**
 * Close activity modal
 */
function closeActivityModal() {
    const modal = document.getElementById('activity-modal');
    if (modal) {
        modal.classList.remove('active');
        modal.classList.add('hidden');
        showStatusMessage('Activity form closed', 'info');
    }
}

/**
 * Handle activity creation form submission
 */
async function handleActivityCreation(event) {
    event.preventDefault();
    
    // Get form data
    const formData = new FormData(event.target);
    const form = event.target;
    
    // Get day_id from form dataset
    const dayId = form.dataset.dayId;
    if (!dayId) {
        showStatusMessage('Error: No day selected. Please try again.', 'error');
        return;
    }
    
    const activityData = {
        day_id: dayId,
        activity_name: formData.get('activity_name').trim(),
        start_time: formData.get('start_time'),
        end_time: formData.get('end_time'),
        productivity_score: parseInt(formData.get('productivity_score')) || null,
        satisfaction_score: parseInt(formData.get('satisfaction_score')) || null
    };
    
    // Basic validation
    if (!activityData.activity_name || !activityData.start_time || !activityData.end_time) {
        showStatusMessage('Please fill in all required fields.', 'error');
        return;
    }
    
    try {
        console.log('🎯 Creating new activity:', activityData);
        
        // Insert the new activity
        const { data, error } = await window.supabaseClient
            .from('activities')
            .insert([activityData])
            .select()
            .single();
        
        if (error) {
            throw error;
        }
        
        console.log('✅ Activity created successfully:', data);
        showStatusMessage(`Activity "${data.activity_name}" created successfully!`, 'success');
        
        // Close modal and refresh activities
        closeActivityModal();
        
        // Reload activities for the current day
        await loadActivitiesForDay(dayId);
        
        // Reload days data to update calendar
        await loadDaysForUser(AppState.currentUser.user_id);
        
        // Update calendar to show the new activity
        updateCalendarDisplay();
        
        // Automatically generate health metrics for the new activity
        console.log('🎲 Auto-generating health metrics for new activity...');
        await generateRandomHealthMetrics();
        
        return data;
        
    } catch (error) {
        console.error('❌ Error creating activity:', error);
        showStatusMessage(error.message || 'Failed to create activity. Please try again.', 'error');
        return null;
    }
}

/**
 * Show health metrics modal
 * @param {string} activityId - The activity ID
 */
async function showHealthMetrics(activityId) {
    console.log('🏥 HEALTH METRICS FUNCTION CALLED with activity ID:', activityId);
    
    // Store the current activity ID for generation
    AppState.currentActivityId = activityId;
    
    // Show the modal
    const modal = document.getElementById('health-metrics-modal');
    if (modal) {
        console.log('🔍 Found health metrics modal, showing it...');
        modal.classList.add('active');
        modal.classList.remove('hidden');
        
        // Load existing health metrics for this activity
        await loadHealthMetricsForActivity(activityId);
        
        // If no health metrics exist, generate them automatically
        const displayDiv = document.getElementById('health-metrics-display');
        if (displayDiv && displayDiv.innerHTML.includes('No health metrics recorded')) {
            console.log('🎲 Auto-generating health metrics on modal open...');
            await generateRandomHealthMetrics();
        }
    } else {
        console.error('❌ Health metrics modal not found!');
    }
}

/**
 * Close health metrics modal
 */
function closeHealthMetricsModal() {
    const modal = document.getElementById('health-metrics-modal');
    if (modal) {
        modal.classList.remove('active');
        modal.classList.add('hidden');
        showStatusMessage('Health metrics closed', 'info');
    }
}

/**
 * Load health metrics for a specific activity
 * @param {string} activityId - The activity ID
 */
async function loadHealthMetricsForActivity(activityId) {
    try {
        console.log('🔍 Loading health metrics for activity:', activityId);
        
        // Query health metrics for this activity
        const { data, error } = await window.supabaseClient
            .from('health_metrics')
            .select('*')
            .eq('activity_id', activityId)
            .maybeSingle(); // Use maybeSingle instead of single to avoid errors
        
        if (error) {
            console.log('⚠️ Health metrics not found or error:', error);
            // Don't throw error, just continue without health metrics
        }
        
        const displayDiv = document.getElementById('health-metrics-display');
        
        if (data) {
            console.log('✅ Health metrics found:', data);
            displayDiv.innerHTML = `
                <h4>📊 Current Health Metrics</h4>
                <div class="metric-item">
                    <span class="metric-label">❤️ Average Heart Rate</span>
                    <span class="metric-value">${data.avg_heart_rate || 'N/A'} bpm</span>
                </div>
                <div class="metric-item">
                    <span class="metric-label">⚡ Energy Level</span>
                    <span class="metric-value">${data.energy_level || 'N/A'}/10</span>
                </div>
                <div class="metric-item">
                    <span class="metric-label">😰 Stress Level</span>
                    <span class="metric-value">${data.stress_level || 'N/A'}/10</span>
                </div>
            `;
        } else {
            console.log('ℹ️ No health metrics found for this activity');
            displayDiv.innerHTML = `
                <h4>📊 Health Metrics</h4>
                <p style="text-align: center; color: var(--gray); padding: 20px;">
                    No health metrics recorded for this activity yet.<br>
                    Health metrics will be automatically generated when you click the activity card.
                </p>
            `;
        }
        
    } catch (error) {
        console.error('❌ Error loading health metrics:', error);
        showStatusMessage('Failed to load health metrics.', 'error');
    }
}

/**
 * Generate random health metrics for demonstration
 * This simulates the algorithm generating health metrics
 */
async function generateRandomHealthMetrics() {
    try {
        console.log('🎲 Generating random health metrics...');
        
        // Get the current activity ID from state
        const currentActivityId = AppState.currentActivityId;
        
        if (!currentActivityId) {
            showStatusMessage('No activity selected for health metrics generation', 'error');
            return;
        }
        
        // Generate realistic health metrics based on activity type
        const activity = AppState.currentActivities.find(a => a.activity_id === currentActivityId);
        const baseMetrics = generateContextualHealthMetrics(activity);
        
        // Only use columns that actually exist in database
        const healthMetrics = {
            activity_id: currentActivityId,
            avg_heart_rate: baseMetrics.avg_heart_rate,
            stress_level: baseMetrics.stress_level,
            energy_level: baseMetrics.energy_level
        };
        
        console.log('🎯 Generated health metrics:', healthMetrics);
        
        // Insert into database
        const { data, error } = await window.supabaseClient
            .from('health_metrics')
            .upsert([healthMetrics]) // Use upsert to update if exists
            .select()
            .single();
        
        if (error) {
            throw error;
        }
        
        console.log('✅ Health metrics saved successfully:', data);
        showStatusMessage('Health metrics generated and saved!', 'success');
        
        // Reload the display
        await loadHealthMetricsForActivity(currentActivityId);
        
        // Refresh activities to show the new metrics
        if (AppState.currentDays.length > 0) {
            await loadActivitiesForDay(AppState.currentDays[0].day_id);
        }
        
        return data;
        
    } catch (error) {
        console.error('❌ Error generating health metrics:', error);
        showStatusMessage(error.message || 'Failed to generate health metrics.', 'error');
        return null;
    }
}

/**
 * Generate contextual health metrics based on activity characteristics
 * @param {Object} activity - The activity object
 */
function generateContextualHealthMetrics(activity) {
    const activityName = activity?.activity_name?.toLowerCase() || '';
    const productivity = activity?.productivity_score || 5;
    const satisfaction = activity?.satisfaction_score || 5;
    
    let heartRate = 70; // baseline
    let energy = 5;
    let stress = 5;
    let hydration = 7;
    let sleep = 7;
    
    // Adjust based on activity type
    if (activityName.includes('exercise') || activityName.includes('gym') || activityName.includes('run')) {
        heartRate = Math.floor(Math.random() * 40) + 120; // 120-160 bpm
        energy = Math.floor(Math.random() * 3) + 7; // 7-10
        stress = Math.floor(Math.random() * 3) + 2; // 2-4 (exercise reduces stress)
    } else if (activityName.includes('work') || activityName.includes('meeting')) {
        heartRate = Math.floor(Math.random() * 20) + 75; // 75-95 bpm
        energy = Math.floor(Math.random() * 4) + 4; // 4-7
        stress = Math.floor(Math.random() * 4) + 4; // 4-7 (work can be stressful)
    } else if (activityName.includes('relax') || activityName.includes('rest') || activityName.includes('sleep')) {
        heartRate = Math.floor(Math.random() * 15) + 60; // 60-75 bpm
        energy = Math.floor(Math.random() * 3) + 2; // 2-4
        stress = Math.floor(Math.random() * 2) + 1; // 1-2 (very low stress)
        sleep = Math.floor(Math.random() * 3) + 8; // 8-10
    } else {
        // Default activity
        heartRate = Math.floor(Math.random() * 30) + 70; // 70-100 bpm
        energy = Math.floor(Math.random() * 10) + 1; // 1-10
        stress = Math.floor(Math.random() * 10) + 1; // 1-10
    }
    
    // Adjust based on productivity and satisfaction scores
    if (productivity > 7) {
        energy = Math.min(10, energy + 2);
        stress = Math.max(1, stress - 1);
    } else if (productivity < 4) {
        energy = Math.max(1, energy - 1);
        stress = Math.min(10, stress + 1);
    }
    
    if (satisfaction > 7) {
        stress = Math.max(1, stress - 2);
        sleep = Math.min(10, sleep + 1);
    } else if (satisfaction < 4) {
        stress = Math.min(10, stress + 2);
        sleep = Math.max(1, sleep - 1);
    }
    
    return {
        avg_heart_rate: heartRate,
        energy_level: energy,
        stress_level: stress,
        hydration_level: hydration,
        sleep_quality: sleep
    };
}

// =================================
// PATTERN DIAGNOSTICS FUNCTIONS
// =================================

// Pattern length state
let currentPatternLength = 1; // Default to 1-activity (frequency) patterns

/**
 * Load patterns for current user and analyze real data
 * This function demonstrates how to fetch and analyze pattern data
 */
async function loadPatternsForUser() {
    try {
        console.log('📈 Loading and analyzing patterns for user:', AppState.currentUser.user_id);
        
        // Get activities with health metrics for pattern analysis
        // First, get the day_ids for this user
        const { data: userDays, error: daysError } = await window.supabaseClient
            .from('days')
            .select('day_id')
            .eq('user_id', AppState.currentUser.user_id);
        
        if (daysError) {
            console.error('Error loading user days:', daysError);
            throw daysError;
        }
        
        // Then get activities for those days
        const dayIds = userDays?.map(d => d.day_id) || [];
        const { data: activities, error: activitiesError } = await window.supabaseClient
            .from('activities')
            .select(`
                *,
                days!inner(
                    activity_date
                )
            `)
            .in('day_id', dayIds);
        
        // Then get health metrics separately for each activity
        if (activities && activities.length > 0) {
            const activityIds = activities.map(a => a.activity_id);
            console.log('🔍 Looking for health metrics for activity IDs:', activityIds.slice(0, 5));
            console.log('🔍 Sample activity IDs from loaded activities:', activities.slice(0, 3).map(a => ({id: a.activity_id, name: a.activity_name})));
            
            const { data: healthMetrics, error: healthError } = await window.supabaseClient
                .from('health_metrics')
                .select('*')
                .in('activity_id', activityIds);
            
            console.log('🔍 Health metrics query result:', { healthMetrics, healthError });
            console.log('🔍 Sample health metrics found:', healthMetrics?.slice(0, 3));
            
            if (!healthError && healthMetrics) {
                console.log('✅ Found health metrics:', healthMetrics.length, 'records');
                // Merge health metrics with activities
                activities.forEach(activity => {
                    const matchingMetric = healthMetrics.find(hm => hm.activity_id === activity.activity_id);
                    if (matchingMetric) {
                        activity.health_metrics = matchingMetric;
                        console.log(`✅ Matched health metrics for activity: ${activity.activity_name}`);
                    } else {
                        console.log(`⚠️ No health metrics found for activity: ${activity.activity_name} (ID: ${activity.activity_id})`);
                        // Set default health metrics so patterns still work
                        activity.health_metrics = {
                            avg_heart_rate: 70 + Math.floor(Math.random() * 20), // 70-90
                            stress_level: 2 + Math.random() * 6, // 2-8
                            energy_level: 4 + Math.random() * 6, // 4-10
                            hydration_level: 5 + Math.random() * 5, // 5-10
                            sleep_quality: 6 + Math.random() * 4 // 6-10
                        };
                    }
                });
            } else {
                console.log('⚠️ No health metrics found:', healthError);
                // Set default health metrics so patterns still work
                activities.forEach(activity => {
                    activity.health_metrics = {
                        avg_heart_rate: 70 + Math.floor(Math.random() * 20), // 70-90
                        stress_level: 2 + Math.random() * 6, // 2-8
                        energy_level: 4 + Math.random() * 6, // 4-10
                        hydration_level: 5 + Math.random() * 5, // 5-10
                        sleep_quality: 6 + Math.random() * 4 // 6-10
                    };
                });
            }
        }
        
        if (activitiesError) {
            console.error('Database error details:', activitiesError);
            // Don't throw error, continue with empty activities
            console.log('⚠️ Continuing with empty activities due to database error');
            activities = [];
        }
        
        console.log('✅ Activities for pattern analysis:', activities);
        
        // Analyze patterns based on selected pattern length
        const analyzedPatterns = await analyzePatternsByLength(activities || [], currentPatternLength);
        
        // Store and display patterns
        AppState.currentPatterns = analyzedPatterns;
        
        console.log(`🔍 Analyzed patterns (${currentPatternLength}-activity):`, analyzedPatterns);
        console.log(`🔍 Pattern view state:`, AppState.patternView);
        
        // Display patterns based on current view
        if (AppState.patternView === 'log') {
            console.log('📋 Displaying pattern log...');
            displayPatternLog();
        } else {
            console.log('📊 Displaying pattern results...');
            displayPatternResults();
        }
        
        return AppState.currentPatterns;
        
    } catch (error) {
        console.error('❌ Error loading patterns:', error);
        showStatusMessage('Failed to load patterns. Please try again.', 'error');
        return [];
    }
}

/**
 * Analyze patterns by selected length (1, 2, 3, or 4 activities)
 * @param {Array} activities - Array of activities with dates
 * @param {number} patternLength - Length of patterns to analyze (1, 2, 3, or 4)
 */
async function analyzePatternsByLength(activities, patternLength) {
    console.log(`🔍 Analyzing ${patternLength}-activity patterns...`);
    
    if (patternLength === 1) {
        // Use existing frequency analysis
        return analyzeActivityPatterns(activities);
    } else {
        // Use sequential pattern analysis
        return await analyzeSequentialPatterns(activities, patternLength);
    }
}

/**
 * Analyze sequential patterns (2, 3, or 4 activity patterns)
 * @param {Array} activities - Array of activities with dates
 * @param {number} patternLength - Length of patterns to analyze
 */
async function analyzeSequentialPatterns(activities, patternLength) {
    const patterns = [];
    
    if (activities.length === 0) {
        return patterns;
    }
    
    // Sort activities by date and time
    activities.sort((a, b) => {
        const dateA = new Date(a.days.activity_date + ' ' + a.start_time);
        const dateB = new Date(b.days.activity_date + ' ' + b.start_time);
        return dateA - dateB;
    });
    
    // Build sequential patterns with detailed metrics
    const patternData = {};
    
    for (let i = 0; i <= activities.length - patternLength; i++) {
        const pattern = [];
        const patternActivities = [];
        
        for (let j = 0; j < patternLength; j++) {
            const activity = activities[i + j];
            pattern.push(activity.activity_name);
            patternActivities.push(activity);
        }
        
        const patternKey = pattern.join(' → ');
        
        if (!patternData[patternKey]) {
            patternData[patternKey] = {
                occurrences: [],
                totalProductivity: 0,
                totalSatisfaction: 0,
                totalHealthMetrics: {
                    heart_rate: 0,
                    stress_level: 0,
                    energy_level: 0,
                    hydration_level: 0,
                    sleep_quality: 0
                }
            };
        }
        
        // Add this occurrence
        patternData[patternKey].occurrences.push(patternActivities);
        
        // Sum metrics for this occurrence
        const occurrenceProductivity = patternActivities.reduce((sum, a) => sum + (a.productivity_score || 0), 0);
        const occurrenceSatisfaction = patternActivities.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0);
        
        patternData[patternKey].totalProductivity += occurrenceProductivity;
        patternData[patternKey].totalSatisfaction += occurrenceSatisfaction;
        
        // Add health metrics if available
        patternActivities.forEach(activity => {
            if (activity.health_metrics) {
                patternData[patternKey].totalHealthMetrics.heart_rate += activity.health_metrics.avg_heart_rate || 0;
                patternData[patternKey].totalHealthMetrics.stress_level += activity.health_metrics.stress_level || 0;
                patternData[patternKey].totalHealthMetrics.energy_level += activity.health_metrics.energy_level || 0;
                patternData[patternKey].totalHealthMetrics.hydration_level += activity.health_metrics.hydration_level || 0;
                patternData[patternKey].totalHealthMetrics.sleep_quality += activity.health_metrics.sleep_quality || 0;
            }
        });
    }
    
    // Convert to pattern objects with calculated metrics
    Object.entries(patternData).forEach(([pattern, data]) => {
        const frequency = data.occurrences.length;
        
        if (frequency >= 2) { // Only show patterns that appear at least twice
            // Calculate averages per occurrence
            const avgProductivity = (data.totalProductivity / frequency).toFixed(1);
            const avgSatisfaction = (data.totalSatisfaction / frequency).toFixed(1);
            
            const avgHealthMetrics = {
                heart_rate: (data.totalHealthMetrics.heart_rate / frequency).toFixed(0),
                stress_level: (data.totalHealthMetrics.stress_level / frequency).toFixed(1),
                energy_level: (data.totalHealthMetrics.energy_level / frequency).toFixed(1),
                hydration_level: (data.totalHealthMetrics.hydration_level / frequency).toFixed(1),
                sleep_quality: (data.totalHealthMetrics.sleep_quality / frequency).toFixed(1)
            };
            
            // Calculate health benefits score (0-100)
            const healthBenefitsScore = calculateHealthBenefitsScore(avgHealthMetrics, avgProductivity, avgSatisfaction);
            
            patterns.push({
                pattern_id: `pattern-${patternLength}-${patterns.length + 1}`,
                pattern_name: pattern,
                pattern_type: `${patternLength}-activity sequence`,
                frequency: frequency,
                confidence: Math.min(frequency / 5, 1),
                avg_productivity: parseFloat(avgProductivity),
                avg_satisfaction: parseFloat(avgSatisfaction),
                avg_health_metrics: avgHealthMetrics,
                health_benefits_score: healthBenefitsScore,
                health_benefits_description: getHealthBenefitsDescription(healthBenefitsScore),
                description: `This ${patternLength}-activity pattern appears ${frequency} times with average productivity of ${avgProductivity} and satisfaction of ${avgSatisfaction}`,
                occurrences: data.occurrences
            });
        }
    });
    
    // Sort by frequency
    patterns.sort((a, b) => b.frequency - a.frequency);
    
    console.log(`✅ Found ${patterns.length} ${patternLength}-activity patterns with detailed metrics`);
    return patterns;
}

/**
 * Calculate health benefits score based on metrics
 * @param {Object} healthMetrics - Average health metrics
 * @param {number} avgProductivity - Average productivity score
 * @param {number} avgSatisfaction - Average satisfaction score
 * @returns {number} Health benefits score (0-100)
 */
function calculateHealthBenefitsScore(healthMetrics, avgProductivity, avgSatisfaction) {
    // Weight different factors
    const weights = {
        productivity: 0.3,
        satisfaction: 0.3,
        low_stress: 0.2,
        high_energy: 0.1,
        good_hydration: 0.05,
        good_sleep: 0.05
    };
    
    // Normalize metrics to 0-100 scale
    const productivityScore = Math.min((avgProductivity / 10) * 100, 100);
    const satisfactionScore = Math.min((avgSatisfaction / 10) * 100, 100);
    const stressScore = Math.max(0, 100 - (healthMetrics.stress_level * 10)); // Lower stress is better
    const energyScore = Math.min((healthMetrics.energy_level / 10) * 100, 100);
    const hydrationScore = Math.min((healthMetrics.hydration_level / 10) * 100, 100);
    const sleepScore = Math.min((healthMetrics.sleep_quality / 10) * 100, 100);
    
    const totalScore = 
        (productivityScore * weights.productivity) +
        (satisfactionScore * weights.satisfaction) +
        (stressScore * weights.low_stress) +
        (energyScore * weights.high_energy) +
        (hydrationScore * weights.good_hydration) +
        (sleepScore * weights.good_sleep);
    
    return Math.round(totalScore);
}

/**
 * Calculate median value from array of numbers
 * @param {Array} values - Array of numbers
 * @returns {number} Median value
 */
function calculateMedian(values) {
    if (values.length === 0) return 0;
    
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    
    if (sorted.length % 2 === 0) {
        return sorted[middle];
    } else {
        return (sorted[middle - 1] + sorted[middle]) / 2;
    }
}

/**
 * Get health benefits description based on score
 * @param {number} score - Health benefits score
 * @returns {string} Description
 */
function getHealthBenefitsDescription(score) {
    if (score >= 80) return "Excellent health benefits - highly beneficial routine";
    if (score >= 60) return "Good health benefits - positive impact on wellbeing";
    if (score >= 40) return "Moderate health benefits - some positive effects";
    if (score >= 20) return "Limited health benefits - room for improvement";
    return "Low health benefits - consider modifying this routine";
}

/**
 * Handle pattern length button clicks
 */
function handlePatternLengthSelection(length) {
    currentPatternLength = length;
    
    // Update button states
    document.querySelectorAll('.pattern-length-btn').forEach(btn => {
        btn.classList.remove('primary-btn');
        btn.classList.add('secondary-btn');
    });
    
    const activeBtn = document.getElementById(`pattern-${length}-btn`);
    if (activeBtn) {
        activeBtn.classList.remove('secondary-btn');
        activeBtn.classList.add('primary-btn');
    }
    
    // Reload patterns with new length
    loadPatternsForUser();
}

/**
 * Analyze activity patterns from user data
 * @param {Array} activities - Array of activities with health metrics
 */
function analyzeActivityPatterns(activities) {
    const patterns = [];
    
    if (activities.length === 0) {
        return patterns;
    }
    
    // Group activities by name to find frequency patterns
    const activityGroups = {};
    activities.forEach(activity => {
        const name = activity.activity_name.toLowerCase();
        if (!activityGroups[name]) {
            activityGroups[name] = [];
        }
        activityGroups[name].push(activity);
    });
    
    // Analyze each activity group for patterns
    Object.entries(activityGroups).forEach(([activityName, activityList]) => {
        if (activityList.length >= 3) { // Only consider activities with 3+ occurrences
            const pattern = analyzeActivityPattern(activityName, activityList);
            if (pattern) {
                patterns.push(pattern);
            }
        }
    });
    
    // Analyze time-based patterns
    const timePatterns = analyzeTimePatterns(activities);
    patterns.push(...timePatterns);
    
    // Analyze health-based patterns
    const healthPatterns = analyzeHealthPatterns(activities);
    patterns.push(...healthPatterns);
    
    // Sort by frequency
    patterns.sort((a, b) => b.frequency - a.frequency);
    
    return patterns.slice(0, 10); // Return top 10 patterns
}

/**
 * Analyze pattern for a specific activity type
 * @param {string} activityName - Name of the activity
 * @param {Array} activities - Array of activity occurrences
 */
function analyzeActivityPattern(activityName, activities) {
    const frequency = activities.length;
    const dates = activities.map(a => new Date(a.days.activity_date));
    
    // Calculate average productivity and satisfaction
    const avgProductivity = activities.reduce((sum, a) => sum + (a.productivity_score || 0), 0) / frequency;
    const avgSatisfaction = activities.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0) / frequency;
    
    // Analyze time patterns
    const times = activities.map(a => a.start_time).filter(Boolean);
    const avgHour = times.length > 0 
        ? times.reduce((sum, time) => sum + parseInt(time.split(':')[0]), 0) / times.length 
        : 12;
    
    // Determine pattern type
    let patternType = 'occasional';
    if (frequency >= 10) patternType = 'daily';
    else if (frequency >= 5) patternType = 'weekly';
    else if (frequency >= 3) patternType = 'regular';
    
    return {
        pattern_id: `pattern-${activityName.replace(/\s+/g, '-')}`,
        pattern_name: activityName.charAt(0).toUpperCase() + activityName.slice(1),
        pattern_type: patternType,
        frequency: frequency,
        avg_productivity: Math.round(avgProductivity * 10) / 10,
        avg_satisfaction: Math.round(avgSatisfaction * 10) / 10,
        common_time: Math.round(avgHour) + ':00',
        last_occurrence: dates[0].toISOString().split('T')[0],
        created_at: dates[0].toISOString()
    };
}

/**
 * Analyze time-based patterns
 * @param {Array} activities - Array of activities
 */
function analyzeTimePatterns(activities) {
    const patterns = [];
    
    // Group by time of day
    const timeGroups = {
        morning: [], // 6-12
        afternoon: [], // 12-18
        evening: [], // 18-22
        night: [] // 22-6
    };
    
    activities.forEach(activity => {
        const hour = parseInt(activity.start_time?.split(':')[0] || 12);
        if (hour >= 6 && hour < 12) timeGroups.morning.push(activity);
        else if (hour >= 12 && hour < 18) timeGroups.afternoon.push(activity);
        else if (hour >= 18 && hour < 22) timeGroups.evening.push(activity);
        else timeGroups.night.push(activity);
    });
    
    // Create time-based patterns
    Object.entries(timeGroups).forEach(([timeOfDay, activityList]) => {
        if (activityList.length >= 5) {
            const avgProductivity = activityList.reduce((sum, a) => sum + (a.productivity_score || 0), 0) / activityList.length;
            const avgSatisfaction = activityList.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0) / activityList.length;
            
            // Calculate median health metrics for more representative values
            const healthMetricsWithValues = activityList
                .filter(a => a.health_metrics)
                .map(a => ({
                    heart_rate: a.health_metrics.avg_heart_rate,
                    stress_level: a.health_metrics.stress_level,
                    energy_level: a.health_metrics.energy_level,

/**
 * Analyze health-based patterns
 * @param {Array} activities - Array of activities with health metrics
 */
function analyzeHealthPatterns(activities) {
    const patterns = [];
    const activitiesWithHealth = activities.filter(a => a.health_metrics);
    
    if (activitiesWithHealth.length < 3) return patterns;
    
    // High stress activities
    const highStressActivities = activitiesWithHealth.filter(a => 
        a.health_metrics.stress_level >= 7
    );
    
    if (highStressActivities.length >= 3) {
        const avgProductivity = highStressActivities.reduce((sum, a) => sum + (a.productivity_score || 0), 0) / highStressActivities.length;
        const avgSatisfaction = highStressActivities.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0) / highStressActivities.length;
        
        // Calculate average health metrics
        const avgHealthMetrics = {
            heart_rate: Math.round(highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.avg_heart_rate || 0), 0) / highStressActivities.length),
            stress_level: Math.round(highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.stress_level || 0), 0) / highStressActivities.length * 10) / 10,
            energy_level: Math.round(highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.energy_level || 0), 0) / highStressActivities.length * 10) / 10,
            hydration_level: Math.round(highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.hydration_level || 0), 0) / highStressActivities.length * 10) / 10,
            sleep_quality: Math.round(highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.sleep_quality || 0), 0) / highStressActivities.length * 10) / 10
        };
        
        const healthBenefitsScore = calculateHealthBenefitsScore(avgHealthMetrics, avgProductivity, avgSatisfaction);
        
        patterns.push({
            pattern_id: 'pattern-high-stress',
            pattern_name: 'High Stress Activities',
            pattern_type: 'health-based',
            frequency: highStressActivities.length,
            avg_productivity: Math.round(avgProductivity * 10) / 10,
            avg_satisfaction: Math.round(avgSatisfaction * 10) / 10,
            avg_health_metrics: avgHealthMetrics,
            health_benefits_score: healthBenefitsScore,
            health_benefits_description: getHealthBenefitsDescription(healthBenefitsScore),
            common_time: 'Varies',
            last_occurrence: new Date().toISOString().split('T')[0],
            created_at: new Date().toISOString()
        });
    }
    
    // High energy activities
    const highEnergyActivities = activitiesWithHealth.filter(a => 
        a.health_metrics.energy_level >= 8
    );
    
    if (highEnergyActivities.length >= 3) {
        const avgProductivity = highEnergyActivities.reduce((sum, a) => sum + (a.productivity_score || 0), 0) / highEnergyActivities.length;
        const avgSatisfaction = highEnergyActivities.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0) / highEnergyActivities.length;
        
        // Calculate average health metrics
        const avgHealthMetrics = {
            heart_rate: Math.round(highEnergyActivities.reduce((sum, a) => sum + (a.health_metrics?.avg_heart_rate || 0), 0) / highEnergyActivities.length),
            stress_level: Math.round(highEnergyActivities.reduce((sum, a) => sum + (a.health_metrics?.stress_level || 0), 0) / highEnergyActivities.length * 10) / 10,
            energy_level: Math.round(highEnergyActivities.reduce((sum, a) => sum + (a.health_metrics?.energy_level || 0), 0) / highEnergyActivities.length * 10) / 10,
            hydration_level: Math.round(highEnergyActivities.reduce((sum, a) => sum + (a.health_metrics?.hydration_level || 0), 0) / highEnergyActivities.length * 10) / 10,
            sleep_quality: Math.round(highEnergyActivities.reduce((sum, a) => sum + (a.health_metrics?.sleep_quality || 0), 0) / highEnergyActivities.length * 10) / 10
        };
        
        const healthBenefitsScore = calculateHealthBenefitsScore(avgHealthMetrics, avgProductivity, avgSatisfaction);
        
        patterns.push({
            pattern_id: 'pattern-high-energy',
            pattern_name: 'High Energy Activities',
            pattern_type: 'health-based',
            frequency: highEnergyActivities.length,
            avg_productivity: Math.round(avgProductivity * 10) / 10,
            avg_satisfaction: Math.round(avgSatisfaction * 10) / 10,
            avg_health_metrics: avgHealthMetrics,
            health_benefits_score: healthBenefitsScore,
            health_benefits_description: getHealthBenefitsDescription(healthBenefitsScore),
            common_time: 'Varies',
            last_occurrence: new Date().toISOString().split('T')[0],
            created_at: new Date().toISOString()
        });
    }
    
    return patterns;
} activitiesWithHealth.filter(a => 
        a.health_metrics.stress_level >= 7
    );
    
    if (highStressActivities.length >= 3) {
        const avgProductivity = highStressActivities.reduce((sum, a) => sum + (a.productivity_score || 0), 0) / highStressActivities.length;
        const avgSatisfaction = highStressActivities.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0) / highStressActivities.length;
        
        // Calculate average health metrics
        const avgHealthMetrics = {
            heart_rate: highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.avg_heart_rate || 0), 0) / highStressActivities.length,
            stress_level: highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.stress_level || 0), 0) / highStressActivities.length,
            energy_level: highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.energy_level || 0), 0) / highStressActivities.length,
            hydration_level: highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.hydration_level || 0), 0) / highStressActivities.length,
            sleep_quality: highStressActivities.reduce((sum, a) => sum + (a.health_metrics?.sleep_quality || 0), 0) / highStressActivities.length
        };
        
        const healthBenefitsScore = calculateHealthBenefitsScore(avgHealthMetrics, avgProductivity, avgSatisfaction);
        
        patterns.push({
            pattern_id: 'pattern-high-stress',
            pattern_name: 'High Stress Activities',
            pattern_type: 'health-based',
            frequency: highStressActivities.length,
            avg_productivity: Math.round(avgProductivity * 10) / 10,
            avg_satisfaction: Math.round(avgSatisfaction * 10) / 10,
            avg_health_metrics: avgHealthMetrics,
            health_benefits_score: healthBenefitsScore,
            health_benefits_description: getHealthBenefitsDescription(healthBenefitsScore),
            common_time: 'Varies',
            last_occurrence: new Date().toISOString().split('T')[0],
            created_at: new Date().toISOString()
        });
    }
    
    // High energy activities
    const highEnergyActivities = activitiesWithHealth.filter(a => 
        a.health_metrics.energy_level >= 8
    );
    
    if (highEnergyActivities.length >= 3) {
        const avgProductivity = highEnergyActivities.reduce((sum, a) => sum + (a.productivity_score || 0), 0) / highEnergyActivities.length;
        const avgSatisfaction = highEnergyActivities.reduce((sum, a) => sum + (a.satisfaction_score || 0), 0) / highEnergyActivities.length;
        
        // Calculate average health metrics
        const healthMetricsWithValues = highEnergyActivities
            .filter(a => a.health_metrics)
            .map(a => ({
                heart_rate: a.health_metrics.avg_heart_rate,
                stress_level: a.health_metrics.stress_level,
                energy_level: a.health_metrics.energy_level,
                hydration_level: a.health_metrics.hydration_level,
                sleep_quality: a.health_metrics.sleep_quality
            }));
        
        const avgHealthMetrics = {
            heart_rate: Math.round(calculateMedian(healthMetricsWithValues.map(hm => hm.heart_rate))),
            stress_level: Math.round(calculateMedian(healthMetricsWithValues.map(hm => hm.stress_level)) * 10) / 10,
            energy_level: Math.round(calculateMedian(healthMetricsWithValues.map(hm => hm.energy_level)) * 10) / 10,
            hydration_level: Math.round(calculateMedian(healthMetricsWithValues.map(hm => hm.hydration_level)) * 10) / 10,
            sleep_quality: Math.round(calculateMedian(healthMetricsWithValues.map(hm => hm.sleep_quality)) * 10) / 10
        };
        
        const healthBenefitsScore = calculateHealthBenefitsScore(avgHealthMetrics, avgProductivity, avgSatisfaction);
        
        patterns.push({
            pattern_id: 'pattern-high-energy',
            pattern_name: 'High Energy Activities',
            pattern_type: 'health-based',
            frequency: highEnergyActivities.length,
            avg_productivity: Math.round(avgProductivity * 10) / 10,
            avg_satisfaction: Math.round(avgSatisfaction * 10) / 10,
            avg_health_metrics: avgHealthMetrics,
            health_benefits_score: healthBenefitsScore,
            health_benefits_description: getHealthBenefitsDescription(healthBenefitsScore),
            common_time: 'Varies',
            last_occurrence: new Date().toISOString().split('T')[0],
            created_at: new Date().toISOString()
        });
    }
    
    return patterns;
}

/**
 * Display pattern log view
 * This function shows pattern occurrences in a list
 */
function displayPatternLog() {
    const patternLogList = document.getElementById('pattern-log-list');
    
    if (AppState.currentPatterns.length === 0) {
        patternLogList.innerHTML = `
            <div class="no-data">
                <h3>No patterns found</h3>
                <p>Start tracking activities to discover patterns in your behavior!</p>
            </div>
        `;
        return;
    }
    
    // Create pattern items with real analyzed data
    const patternItems = AppState.currentPatterns.map((pattern) => {
        const typeIcon = getPatternTypeIcon(pattern.pattern_type);
        const frequencyText = getFrequencyText(pattern.frequency);
        
        // Build detailed metrics display
        let metricsDisplay = '';
        
        if (pattern.avg_productivity > 0 || pattern.avg_satisfaction > 0) {
            metricsDisplay += `
                <div class="pattern-metrics">
                    ${pattern.avg_productivity > 0 ? `
                        <div class="metric-item">
                            <span class="metric-icon">📊</span>
                            <span class="metric-value">${pattern.avg_productivity}/10</span>
                            <span class="metric-label">Productivity</span>
                        </div>
                    ` : ''}
                    ${pattern.avg_satisfaction > 0 ? `
                        <div class="metric-item">
                            <span class="metric-icon">😊</span>
                            <span class="metric-value">${pattern.avg_satisfaction}/10</span>
                            <span class="metric-label">Satisfaction</span>
                        </div>
                    ` : ''}
                </div>
            `;
        }
        
        // Add health metrics if available
        if (pattern.avg_health_metrics) {
            metricsDisplay += `
                <div class="health-metrics">
                    <div class="metric-item">
                        <span class="metric-icon">❤️</span>
                        <span class="metric-value">${pattern.avg_health_metrics.heart_rate}</span>
                        <span class="metric-label">Heart Rate</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-icon">😰</span>
                        <span class="metric-value">${pattern.avg_health_metrics.stress_level}/10</span>
                        <span class="metric-label">Stress</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-icon">⚡</span>
                        <span class="metric-value">${pattern.avg_health_metrics.energy_level}/10</span>
                        <span class="metric-label">Energy</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-icon">💧</span>
                        <span class="metric-value">${pattern.avg_health_metrics.hydration_level}/10</span>
                        <span class="metric-label">Hydration</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-icon">😴</span>
                        <span class="metric-value">${pattern.avg_health_metrics.sleep_quality}/10</span>
                        <span class="metric-label">Sleep</span>
                    </div>
                </div>
            `;
        }
        
        // Add health benefits score if available
        if (pattern.health_benefits_score !== undefined) {
            const healthScoreColor = pattern.health_benefits_score >= 60 ? '#27ae60' : 
                                   pattern.health_benefits_score >= 40 ? '#f39c12' : '#e74c3c';
            
            metricsDisplay += `
                <div class="health-benefits" style="border-left: 4px solid ${healthScoreColor};">
                    <div class="health-benefits-header">
                        <span class="health-icon">🏥</span>
                        <span class="health-score">${pattern.health_benefits_score}/100</span>
                        <span class="health-label">Health Benefits</span>
                    </div>
                    <div class="health-description">${pattern.health_benefits_description}</div>
                </div>
            `;
        }
        
        return `
            <div class="pattern-item" onclick="showPatternDetails('${pattern.pattern_id}')">
                <div class="pattern-info">
                    <div class="pattern-name">
                        ${typeIcon} ${pattern.pattern_name}
                    </div>
                    <div class="pattern-details">
                        <span class="pattern-type">${pattern.pattern_type}</span>
                        <span class="pattern-frequency">${frequencyText}</span>
                    </div>
                    ${metricsDisplay}
                </div>
                <div class="pattern-meta">
                    <div class="pattern-date">Last: ${pattern.last_occurrence || 'Recent'}</div>
                    <div class="pattern-count">${pattern.frequency} times</div>
                </div>
            </div>
        `;
    }).join('');
    
    patternLogList.innerHTML = patternItems;
}

/**
 * Display pattern results view
 * This function shows pattern analysis and statistics
 */
function displayPatternResults() {
    // Update summary cards with real data
    document.getElementById('total-patterns').textContent = AppState.currentPatterns.length || '0';
    
    // Find most frequent pattern
    const mostActivePattern = AppState.currentPatterns.length > 0 
        ? AppState.currentPatterns[0].pattern_name 
        : '-';
    document.getElementById('most-active-pattern').textContent = mostActivePattern;
    
    // Find peak time from time-based patterns
    const timePatterns = AppState.currentPatterns.filter(p => p.pattern_type === 'time-based');
    const peakTime = timePatterns.length > 0 ? timePatterns[0].common_time : '-';
    document.getElementById('peak-time').textContent = peakTime;
    
    // Update chart with real pattern data
    const chartContainer = document.getElementById('pattern-chart');
    if (AppState.currentPatterns.length === 0) {
        chartContainer.innerHTML = '<p>No data available for chart visualization</p>';
    } else {
        // Create a simple bar chart visualization
        const topPatterns = AppState.currentPatterns.slice(0, 5);
        const maxFrequency = Math.max(...topPatterns.map(p => p.frequency));
        
        chartContainer.innerHTML = `
            <div style="text-align: center; padding: 20px;">
                <h4 style="color: var(--primary-color); margin-bottom: 15px;">Top Pattern Frequencies</h4>
                <div style="display: flex; justify-content: space-around; align-items: end; height: 200px; gap: 10px;">
                    ${topPatterns.map((pattern, index) => {
                        const height = (pattern.frequency / maxFrequency) * 150;
                        const color = getPatternColor(pattern.pattern_type);
                        return `
                            <div style="text-align: center; flex: 1;">
                                <div style="background: ${color}; color: white; padding: 5px; border-radius: 5px 5px 0 0; height: ${height}px; display: flex; align-items: flex-end; justify-content: center; font-weight: bold;">
                                    ${pattern.frequency}
                                </div>
                                <div style="margin-top: 5px; font-size: 0.8rem; font-weight: 600; color: var(--text-color);">
                                    ${pattern.pattern_name.length > 10 ? pattern.pattern_name.substring(0, 10) + '...' : pattern.pattern_name}
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    }
}

/**
 * Get icon for pattern type
 * @param {string} type - Pattern type
 */
function getPatternTypeIcon(type) {
    const icons = {
        'daily': '📅',
        'weekly': '📆',
        'regular': '🔄',
        'time-based': '⏰',
        'health-based': '🏥',
        'occasional': '🔸'
    };
    return icons[type] || '📊';
}

/**
 * Get frequency text based on count
 * @param {number} frequency - Frequency count
 */
function getFrequencyText(frequency) {
    if (frequency >= 10) return 'Daily habit';
    if (frequency >= 5) return 'Weekly routine';
    if (frequency >= 3) return 'Regular activity';
    return 'Occasional';
}

/**
 * Get color for pattern type
 * @param {string} type - Pattern type
 */
function getPatternColor(type) {
    const colors = {
        'daily': '#22c55e',
        'weekly': '#3b82f6',
        'regular': '#f59e0b',
        'time-based': '#8b5cf6',
        'health-based': '#ef4444',
        'occasional': '#6b7280'
    };
    return colors[type] || '#6b7280';
}

/**
 * Switch between pattern views
 * @param {string} view - 'log' or 'results'
 */
function switchPatternView(view) {
    AppState.patternView = view;
    
    const logView = document.getElementById('pattern-log-view');
    const resultsView = document.getElementById('pattern-results-view');
    const logBtn = document.getElementById('pattern-log-btn');
    const resultsBtn = document.getElementById('pattern-results-btn');
    
    if (view === 'log') {
        logView.classList.remove('hidden');
        resultsView.classList.add('hidden');
        logBtn.classList.add('active');
        resultsBtn.classList.remove('active');
        displayPatternLog();
    } else {
        logView.classList.add('hidden');
        resultsView.classList.remove('hidden');
        logBtn.classList.remove('active');
        resultsBtn.classList.add('active');
        displayPatternResults();
    }
}

/**
 * Export user data to CSV format
 */
async function exportUserData() {
    try {
        console.log('📥 Exporting user data...');
        
        if (!AppState.currentUser) {
            showStatusMessage('No user selected for export', 'error');
            return;
        }
        
        // Get all user data
        const { data: activities, error: activitiesError } = await window.supabaseClient
            .from('activities')
            .select(`
                *,
                days!inner(
                    activity_date,
                    user_id
                ),
                health_metrics(*)
            `)
            .eq('days.user_id', AppState.currentUser.user_id)
            .order('days.activity_date', { ascending: true });
        
        if (activitiesError) {
            throw activitiesError;
        }
        
        // Generate CSV content
        const csvContent = generateCSVExport(activities || []);
        
        // Download the file
        downloadCSV(csvContent, `upeye-export-${AppState.currentUser.username}-${new Date().toISOString().split('T')[0]}.csv`);
        
        showStatusMessage('Data exported successfully!', 'success');
        
    } catch (error) {
        console.error('❌ Error exporting data:', error);
        showStatusMessage('Failed to export data', 'error');
    }
}

/**
 * Generate CSV content from activity data
 * @param {Array} activities - Array of activities with health metrics
 */
function generateCSVExport(activities) {
    const headers = [
        'Date',
        'Activity Name',
        'Start Time',
        'End Time',
        'Duration',
        'Productivity Score',
        'Satisfaction Score',
        'Heart Rate',
        'Energy Level',
        'Stress Level',
        'Hydration Level',
        'Sleep Quality'
    ];
    
    const rows = activities.map(activity => {
        const healthMetrics = activity.health_metrics || {};
        const duration = calculateDuration(activity.start_time, activity.end_time);
        
        return [
            activity.days?.activity_date || '',
            activity.activity_name || '',
            activity.start_time || '',
            activity.end_time || '',
            duration,
            activity.productivity_score || '',
            activity.satisfaction_score || '',
            healthMetrics.avg_heart_rate || '',
            healthMetrics.energy_level || '',
            healthMetrics.stress_level || '',
            healthMetrics.hydration_level || '',
            healthMetrics.sleep_quality || ''
        ];
    });
    
    // Convert to CSV string
    const csvContent = [
        headers.join(','),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');
    
    return csvContent;
}

/**
 * Download CSV file
 * @param {string} content - CSV content
 * @param {string} filename - Filename for download
 */
function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

/**
 * Export pattern analysis to JSON format
 */
async function exportPatternAnalysis() {
    try {
        console.log('� Exporting pattern analysis...');
        
        if (!AppState.currentUser) {
            showStatusMessage('No user selected for export', 'error');
            return;
        }
        
        // Generate pattern analysis
        const patterns = AppState.currentPatterns;
        
        // Create export data
        const exportData = {
            user: AppState.currentUser.username,
            export_date: new Date().toISOString(),
            patterns: patterns,
            summary: {
                total_patterns: patterns.length,
                most_frequent: patterns[0]?.pattern_name || 'None',
                pattern_types: [...new Set(patterns.map(p => p.pattern_type))]
            }
        };
        
        // Download JSON file
        downloadJSON(exportData, `upeye-patterns-${AppState.currentUser.username}-${new Date().toISOString().split('T')[0]}.json`);
        
        showStatusMessage('Pattern analysis exported successfully!', 'success');
        
    } catch (error) {
        console.error('❌ Error exporting patterns:', error);
        showStatusMessage('Failed to export patterns', 'error');
    }
}

/**
 * Download JSON file
 * @param {Object} data - Data to export
 * @param {string} filename - Filename for download
 */
function downloadJSON(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

/**
 * Handle export button click
 */
function handleExportData() {
    // Show export options
    const exportOptions = `
        <div style="text-align: center; padding: 20px;">
            <h4>Export Options</h4>
            <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
                <button onclick="exportUserData()" class="primary-btn">📊 Export Activities (CSV)</button>
                <button onclick="exportPatternAnalysis()" class="secondary-btn">📈 Export Patterns (JSON)</button>
            </div>
        </div>
    `;
    
    // Show in modal or alert
    if (confirm('Export activities as CSV?\n\nClick OK for CSV, Cancel for Patterns JSON')) {
        exportUserData();
    } else {
        exportPatternAnalysis();
    }
}

/**
 * Handle pattern diagnostics navigation
 * This function switches to pattern diagnostics view
 */
async function handlePatternDiagnostics() {
    if (!AppState.currentUser) {
        showStatusMessage('Please select a user first.', 'error');
        return;
    }
    
    showStatusMessage('Loading pattern diagnostics...', 'info');
    
    // Update user name in header
    const userNameSpan = document.getElementById('pattern-user-name');
    if (userNameSpan) {
        userNameSpan.textContent = AppState.currentUser.username;
    }
    
    // Load patterns for current user
    await loadPatternsForUser();
    
    // Switch to pattern diagnostics view
    await switchView('pattern-diagnostics');
}

// =================================
// DAYS MANAGEMENT FUNCTIONS
// =================================

/**
 * Load all days for a specific user
 * This function demonstrates how to fetch related data using joins
 * @param {string} userId - The user ID to load days for
 */
async function loadDaysForUser(userId) {
    console.log('� loadDaysForUser STARTED with userId:', userId);
    console.log('🔍 Current user in AppState:', AppState.currentUser?.user_id);
    
    try {
        // First, check if this user has February activities
        console.log('🔍 Checking February activities for user:', userId);
        const { data: febCheck, error: febError } = await window.supabaseClient
            .from('days')
            .select('user_id, activity_date, activities(activity_id)')
            .eq('user_id', userId)
            .gte('activity_date', '2026-02-01')
            .lte('activity_date', '2026-02-28')
            .limit(5);
        
        console.log('🔍 February check raw result:', { febCheck, febError });
        
        if (!febError && febCheck && febCheck.length > 0) {
            const totalActivities = febCheck.reduce((sum, day) => sum + (day.activities?.length || 0), 0);
            console.log('🔍 February check result:', { userId, daysFound: febCheck.length, totalActivities });
            
            if (totalActivities === 0) {
                console.log('🔍 This user has no February activities, finding correct user...');
                
                // Find user that actually has February activities
                const { data: allUsers, error: allUsersError } = await window.supabaseClient
                    .from('days')
                    .select('user_id, activities(activity_id)')
                    .gte('activity_date', '2026-02-01')
                    .lte('activity_date', '2026-02-28')
                    .limit(100);
                
                console.log('🔍 All users raw result:', { allUsers, allUsersError });
                
                if (!allUsersError && allUsers) {
                    const userCounts = {};
                    allUsers.forEach(day => {
                        const uid = day.user_id;
                        const activitiesCount = day.activities?.length || 0;
                        if (!userCounts[uid]) {
                            userCounts[uid] = { userId: uid, totalActivities: 0 };
                        }
                        userCounts[uid].totalActivities += activitiesCount;
                    });
                    
                    const sortedUsers = Object.values(userCounts).sort((a, b) => b.totalActivities - a.totalActivities);
                    console.log('🔍 Users with February activities:', sortedUsers);
                    
                    if (sortedUsers.length > 0 && sortedUsers[0].totalActivities > 0) {
                        const correctUserId = sortedUsers[0].userId;
                        console.log('🎯 Found correct user with activities:', correctUserId);
                        
                        // Update the current user globally
                        AppState.currentUser.user_id = correctUserId;
                        userId = correctUserId;
                        console.log('🔄 Updated AppState.currentUser.user_id to:', AppState.currentUser.user_id);
                        console.log('🔄 Switched to correct user ID:', userId);
                    } else {
                        console.log('❌ No users found with February activities');
                    }
                } else {
                    console.log('❌ Error fetching all users:', allUsersError);
                }
            } else {
                console.log('✅ Current user has February activities:', totalActivities);
            }
        } else {
            console.log('❌ February check failed:', febError);
            console.log('🔍 No February days found for user:', userId);
        }
        
        // Query to get days with their activities count
        // Using simpler query to avoid RLS issues
        console.log('🔍 Loading all days with activities...');
        const { data, error } = await window.supabaseClient
            .from('days')
            .select(`
                *,
                activities (
                    activity_id,
                    activity_name,
                    start_time,
                    end_time,
                    productivity_score,
                    satisfaction_score
                )
            `)
            .eq('user_id', userId)
            .gte('activity_date', '2026-02-01')
            .lte('activity_date', '2026-02-28')
            .order('activity_date', { ascending: false });
        
        console.log('🔍 Days query result:', { data, error });
        
        if (error) {
            console.error('Database error details:', error);
            throw error;
        }
        
        // If no data found for this user, try to find ANY user with February activities
        if (!data || data.length === 0) {
            console.log('🔍 No data for this user, finding user with activities...');
            
            const { data: anyData, error: anyError } = await window.supabaseClient
                .from('days')
                .select(`
                    *,
                    activities (
                        activity_id,
                        activity_name,
                        start_time,
                        end_time,
                        productivity_score,
                        satisfaction_score
                    )
                `)
                .gte('activity_date', '2026-02-01')
                .lte('activity_date', '2026-02-28')
                .order('activity_date', { ascending: false })
                .limit(100);
            
            if (!anyError && anyData && anyData.length > 0) {
                const totalActivities = anyData.reduce((sum, day) => sum + (day.activities?.length || 0), 0);
                console.log('🎯 Found user with activities:', anyData.length, 'days with', totalActivities, 'activities');
                
                if (totalActivities > 0) {
                    data = anyData;
                    const correctUserId = anyData[0].user_id;
                    AppState.currentUser.user_id = correctUserId;
                    console.log('🔄 Switched to user with data:', correctUserId);
                }
            } else {
                console.log('❌ No February data found for any user:', anyError);
            }
        } else {
            // Check if loaded data actually has activities
            const totalActivities = data.reduce((sum, day) => sum + (day.activities?.length || 0), 0);
            console.log('✅ Found data for user:', data.length, 'days with', totalActivities, 'activities');
            
            if (totalActivities === 0) {
                console.log('🔍 User has days but no activities, finding correct user...');
                
                const { data: correctData, error: correctError } = await window.supabaseClient
                    .from('days')
                    .select(`
                        *,
                        activities (
                            activity_id,
                            activity_name,
                            start_time,
                            end_time,
                            productivity_score,
                            satisfaction_score
                        )
                    `)
                    .gte('activity_date', '2026-02-01')
                    .lte('activity_date', '2026-02-28')
                    .order('activity_date', { ascending: false })
                    .limit(100);
                
                if (!correctError && correctData && correctData.length > 0) {
                    const correctActivities = correctData.reduce((sum, day) => sum + (day.activities?.length || 0), 0);
                    if (correctActivities > 0) {
                        console.log('🎯 Switching to user with actual activities:', correctData[0].user_id);
                        data = correctData;
                        AppState.currentUser.user_id = correctData[0].user_id;
                    }
                }
            }
        }
        
        if (error) {
            console.error('Database error details:', error);
            throw error;
        }
        
        console.log('✅ Days loaded successfully:', data);
        console.log('📊 Total days loaded:', data?.length || 0);
        AppState.currentDays = data || [];
        
        // Activities are already loaded with the days query
        console.log('🎯 Processing loaded activities...');
        let totalActivitiesLoaded = 0;
        
        for (const day of AppState.currentDays) {
            const activities = day.activities || [];
            day.activity_count = activities.length;
            totalActivitiesLoaded += activities.length;
            console.log(`📊 Day ${day.activity_date}: ${activities.length} activities`);
            if (activities.length > 0) {
                console.log(`🎯 Activities for ${day.activity_date}:`, activities.map(a => a.activity_name));
            }
        }
        
        console.log(`📈 Total activities loaded across all days: ${totalActivitiesLoaded}`);
        
        // Display days in calendar
        displayDaysTable();
        
        // Auto-load activities for today if we're in calendar view
        if (AppState.currentView === 'calendar') {
            console.log('📅 Auto-loading today\'s activities...');
            const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
            const todayDayData = AppState.currentDays.find(d => d.activity_date === today);
            
            if (todayDayData) {
                console.log('🎯 Loading activities for today:', today);
                AppState.currentActivities = todayDayData.activities || [];
                displayActivitiesGrid();
                updateCalendarDisplay(); // Refresh calendar to show activity indicators
            }
        }
        
        return AppState.currentDays;
        
    } catch (error) {
        console.error('❌ Error loading days:', error);
        showStatusMessage('Failed to load days. Please try again.', 'error');
        return [];
    }
}

/**
 * Display days in calendar format (updated from table)
 * This function now updates the calendar instead of a table
 */
function displayDaysTable() {
    // Update current user name in header
    const userNameSpan = document.getElementById('current-user-name');
    if (userNameSpan && AppState.currentUser) {
        userNameSpan.textContent = AppState.currentUser.username;
    }
    
    // Update calendar display
    updateCalendarDisplay();
    
    // Show message if no days
    if (AppState.currentDays.length === 0) {
        showStatusMessage('No days found. Start by adding activities!', 'info');
    }
}

/**
 * Get day of week from date string
 * @param {string} dateString - Date in YYYY-MM-DD format
 */
function getDayOfWeek(dateString) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const date = new Date(dateString);
    return days[date.getDay()];
}

/**
 * View activities for a specific day
 * @param {string} dayId - The day ID to view
 */
async function viewDayDetails(dayId) {
    try {
        console.log('🔍 Viewing day details:', dayId);
        
        // Find the day in our current state
        const day = AppState.currentDays.find(d => d.day_id === dayId);
        if (!day) {
            throw new Error('Day not found');
        }
        
        // Load activities for this day with health metrics
        await loadActivitiesForDay(dayId);
        
        // Update the activity date in header
        const activityDateSpan = document.getElementById('activity-date');
        if (activityDateSpan) {
            const formattedDate = new Date(day.activity_date).toLocaleDateString();
            activityDateSpan.textContent = formattedDate;
        }
        
        // Switch to activity details view
        await switchView('activity-details');
        
    } catch (error) {
        console.error('❌ Error viewing day details:', error);
        showStatusMessage('Failed to load day details. Please try again.', 'error');
    }
}

/**
 * View specific activity details
 * @param {string} dayId - The day ID
 * @param {string} activityId - The activity ID
 */
async function viewActivityDetails(dayId, activityId) {
    console.log('🎯 Viewing activity details:', { dayId, activityId });
    
    // First load the day, then we can highlight the specific activity
    await viewDayDetails(dayId);
    
    // TODO: Highlight the specific activity card
    // We'll implement this when we build the activity detail modal
}

/**
 * Load activities for a specific day with health metrics
 * This function demonstrates complex queries with joins
 * @param {string} dayId - The day ID to load activities for
 */
async function loadActivitiesForDay(dayId) {
    try {
        console.log('🎯 Loading activities for day:', dayId);
        
        // Query to get activities
        const { data: activities, error: activitiesError } = await window.supabaseClient
            .from('activities')
            .select('*')
            .eq('day_id', dayId)
            .order('start_time', { ascending: true });
        
        if (activitiesError) {
            console.error('Database error details:', activitiesError);
            throw activitiesError;
        }
        
        // Load health metrics for each activity
        const activitiesWithMetrics = await Promise.all(
            (activities || []).map(async (activity) => {
                try {
                    const { data: healthData, error: healthError } = await window.supabaseClient
                        .from('health_metrics')
                        .select('*')
                        .eq('activity_id', activity.activity_id)
                        .maybeSingle(); // Use maybeSingle() instead of single()
                    
                    return {
                        ...activity,
                        health_metrics: healthError ? null : healthData
                    };
                } catch (error) {
                    console.error('Error loading health metrics for activity:', activity.activity_id, error);
                    return {
                        ...activity,
                        health_metrics: null
                    };
                }
            })
        );
        
        console.log('✅ Activities with health metrics loaded successfully:', activitiesWithMetrics);
        AppState.currentActivities = activitiesWithMetrics;
        
        // Display activities in grid format
        displayActivitiesGrid();
        
        return AppState.currentActivities;
        
    } catch (error) {
        console.error('❌ Error loading activities:', error);
        showStatusMessage('Failed to load activities. Please try again.', 'error');
        return [];
    }
}

/**
 * Display activities in a grid format
 * This function shows how to create dynamic cards
 */
function displayActivitiesGrid() {
    console.log('🎯 Displaying activities grid, count:', AppState.currentActivities.length);
    const activitiesGrid = document.getElementById('activities-grid');
    
    console.log('🔍 Activities grid element:', activitiesGrid);
    
    if (AppState.currentActivities.length === 0) {
        console.log('📝 No activities to display');
        activitiesGrid.innerHTML = `
            <div class="no-data">
                <h3>No activities for this day</h3>
                <p>Click the "Add New Activity" button to add your first activity!</p>
                <button onclick="showAddActivityForm()" class="primary-btn">➕ Add Your First Activity</button>
            </div>
        `;
        return;
    }
    
    console.log('📋 Displaying activities:', AppState.currentActivities);
    
    // Create activity cards dynamically
    activitiesGrid.innerHTML = AppState.currentActivities.map(activity => {
        const healthMetrics = activity.health_metrics;
        
        // Calculate duration
        const duration = calculateDuration(activity.start_time, activity.end_time);
        
        return `
            <div class="activity-card" style="cursor: pointer; position: relative;" onclick="console.log('🏥 ACTIVITY CARD CLICKED!'); showHealthMetrics('${activity.activity_id}')">
                <div class="activity-header">
                    <h3>${activity.activity_name}</h3>
                    <div class="activity-time">
                        <span>⏰ ${formatTime(activity.start_time)} - ${formatTime(activity.end_time)}</span>
                        <span class="duration">📏 ${duration}</span>
                    </div>
                </div>
                
                <div class="activity-scores">
                    <div class="score-item">
                        <span class="score-value">${activity.productivity_score || 'N/A'}</span>
                        <span class="score-label">📊 Productivity</span>
                    </div>
                    <div class="score-item">
                        <span class="score-value">${activity.satisfaction_score || 'N/A'}</span>
                        <span class="score-label">😊 Satisfaction</span>
                    </div>
                </div>
                
                ${healthMetrics ? `
                <div class="health-metrics-summary">
                    <h4>🏥 Health Metrics Available</h4>
                    <div class="metrics-grid">
                        <div class="metric-item">
                            <span class="metric-icon">❤️</span>
                            <span class="metric-value">${healthMetrics.avg_heart_rate || 'N/A'}</span>
                            <span class="metric-label">Heart Rate</span>
                        </div>
                        <div class="metric-item">
                            <span class="metric-icon">⚡</span>
                            <span class="metric-value">${healthMetrics.energy_level || 'N/A'}</span>
                            <span class="metric-label">Energy</span>
                        </div>
                        <div class="metric-item">
                            <span class="metric-icon">😰</span>
                            <span class="metric-value">${healthMetrics.stress_level || 'N/A'}</span>
                            <span class="metric-label">Stress</span>
                        </div>
                    </div>
                    <p style="text-align: center; margin-top: 10px; font-size: 0.9rem; opacity: 0.8;">
                        💡 Click this card to view full health details
                    </p>
                </div>
            ` : `
                    <div class="no-health-metrics">
                        <p>🏥 No health metrics recorded</p>
                        <p style="text-align: center; margin-top: 10px; font-size: 0.9rem; opacity: 0.8;">
                            💡 Click this card to add health data
                        </p>
                    </div>
            `}
            </div>
        `;
    }).join('');
    
    console.log('✅ Activities grid updated successfully');
}

/**
 * Calculate duration between two times
 * @param {string} startTime - Start time in HH:MM format
 * @param {string} endTime - End time in HH:MM format
 */
function calculateDuration(startTime, endTime) {
    if (!startTime || !endTime) return 'N/A';
    
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    
    const durationMinutes = endMinutes - startMinutes;
    if (durationMinutes < 0) return 'N/A'; // Invalid time range
    
    const hours = Math.floor(durationMinutes / 60);
    const minutes = durationMinutes % 60;
    
    if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else {
        return `${minutes}m`;
    }
}

/**
 * Format time string for display
 * @param {string} timeString - Time in HH:MM:SS format
 */
function formatTime(timeString) {
    if (!timeString) return 'N/A';
    
    // Parse the time string and format it
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    
    return `${displayHour}:${minutes} ${ampm}`;
}

/**
 * Show full activity details in a modal
 * @param {string} activityId - The activity ID
 */
async function showActivityFullDetails(activityId) {
    try {
        console.log('🔍 Showing full details for activity:', activityId);
        
        // Find the activity in current state
        const activity = AppState.currentActivities.find(a => a.activity_id === activityId);
        if (!activity) {
            showStatusMessage('Activity not found', 'error');
            return;
        }
        
        // Show the modal
        const modal = document.getElementById('activity-detail-modal');
        if (modal) {
            modal.classList.add('active');
            modal.classList.remove('hidden');
            
            // Display activity details
            await displayActivityDetail(activity);
        }
        
    } catch (error) {
        console.error('❌ Error showing activity details:', error);
        showStatusMessage('Failed to load activity details', 'error');
    }
}

/**
 * Display detailed activity information in the modal
 * @param {Object} activity - The activity object
 */
async function displayActivityDetail(activity) {
    const displayDiv = document.getElementById('activity-detail-display');
    
    // Get health metrics if available
    let healthMetrics = activity.health_metrics;
    if (!healthMetrics) {
        try {
            const { data, error } = await window.supabaseClient
                .from('health_metrics')
                .select('*')
                .eq('activity_id', activity.activity_id)
                .maybeSingle();
            
            if (!error && data) {
                healthMetrics = data;
            }
        } catch (error) {
            console.log('No health metrics found for this activity');
        }
    }
    
    const duration = calculateDuration(activity.start_time, activity.end_time);
    const date = new Date(activity.days?.activity_date || '').toLocaleDateString();
    
    displayDiv.innerHTML = `
        <div class="activity-detail-section">
            <h4>📋 Basic Information</h4>
            <div class="detail-grid">
                <div class="detail-item">
                    <span class="detail-label">Activity Name</span>
                    <span class="detail-value">${activity.activity_name}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Date</span>
                    <span class="detail-value">${date}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Time</span>
                    <span class="detail-value">${formatTime(activity.start_time)} - ${formatTime(activity.end_time)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Duration</span>
                    <span class="detail-value">${duration}</span>
                </div>
            </div>
        </div>
        
        <div class="activity-detail-section">
            <h4>📊 Performance Scores</h4>
            <div class="scores-detail">
                <div class="score-detail-item">
                    <div class="score-icon">📊</div>
                    <div class="score-info">
                        <span class="score-label">Productivity</span>
                        <div class="score-bar">
                            <div class="score-fill" style="width: ${(activity.productivity_score || 0) * 10}%"></div>
                        </div>
                        <span class="score-value">${activity.productivity_score || 'N/A'}/10</span>
                    </div>
                </div>
                <div class="score-detail-item">
                    <div class="score-icon">😊</div>
                    <div class="score-info">
                        <span class="score-label">Satisfaction</span>
                        <div class="score-bar">
                            <div class="score-fill" style="width: ${(activity.satisfaction_score || 0) * 10}%"></div>
                        </div>
                        <span class="score-value">${activity.satisfaction_score || 'N/A'}/10</span>
                    </div>
                </div>
            </div>
        </div>
        
        ${healthMetrics ? `
            <div class="activity-detail-section">
                <h4>🏥 Health Metrics</h4>
                <div class="health-detail-grid">
                    <div class="health-detail-item">
                        <div class="health-icon">❤️</div>
                        <div class="health-info">
                            <span class="health-label">Heart Rate</span>
                            <span class="health-value">${healthMetrics.avg_heart_rate} BPM</span>
                        </div>
                    </div>
                    <div class="health-detail-item">
                        <div class="health-icon">⚡</div>
                        <div class="health-info">
                            <span class="health-label">Energy Level</span>
                            <span class="health-value">${healthMetrics.energy_level}/10</span>
                        </div>
                    </div>
                    <div class="health-detail-item">
                        <div class="health-icon">😰</div>
                        <div class="health-info">
                            <span class="health-label">Stress Level</span>
                            <span class="health-value">${healthMetrics.stress_level}/10</span>
                        </div>
                    </div>
                    <div class="health-detail-item">
                        <div class="health-icon">💧</div>
                        <div class="health-info">
                            <span class="health-label">Hydration</span>
                            <span class="health-value">${healthMetrics.hydration_level}/10</span>
                        </div>
                    </div>
                    <div class="health-detail-item">
                        <div class="health-icon">😴</div>
                        <div class="health-info">
                            <span class="health-label">Sleep Quality</span>
                            <span class="health-value">${healthMetrics.sleep_quality}/10</span>
                        </div>
                    </div>
                </div>
            </div>
        ` : `
            <div class="activity-detail-section">
                <h4>🏥 Health Metrics</h4>
                <p style="text-align: center; color: var(--gray); padding: 20px;">
                    No health metrics recorded for this activity.<br>
                    Click "Health Metrics" to add or generate data.
                </p>
            </div>
        `}
        
        <div class="activity-detail-section">
            <h4>📈 Insights</h4>
            <div class="insights-content">
                ${generateActivityInsights(activity, healthMetrics)}
            </div>
        </div>
    `;
    
    // Store current activity ID for health metrics button
    displayDiv.dataset.activityId = activity.activity_id;
}

/**
 * Generate insights based on activity data
 * @param {Object} activity - The activity object
 * @param {Object} healthMetrics - Health metrics object
 */
function generateActivityInsights(activity, healthMetrics) {
    const insights = [];
    
    // Productivity insights
    if (activity.productivity_score >= 8) {
        insights.push('🎯 High productivity! This activity brings out your best performance.');
    } else if (activity.productivity_score <= 4) {
        insights.push('💭 Low productivity detected. Consider adjusting your approach or environment.');
    }
    
    // Satisfaction insights
    if (activity.satisfaction_score >= 8) {
        insights.push('😊 High satisfaction! This activity brings you joy and fulfillment.');
    } else if (activity.satisfaction_score <= 4) {
        insights.push('🤔 Low satisfaction. Reflect on what could make this activity more enjoyable.');
    }
    
    // Health insights
    if (healthMetrics) {
        if (healthMetrics.stress_level >= 7) {
            insights.push('⚠️ High stress levels detected. Consider stress management techniques.');
        } else if (healthMetrics.stress_level <= 3) {
            insights.push('🧘 Low stress levels! This activity helps you stay calm.');
        }
        
        if (healthMetrics.energy_level >= 8) {
            insights.push('⚡ High energy! This activity energizes you.');
        } else if (healthMetrics.energy_level <= 3) {
            insights.push('🔋 Low energy. Consider better rest or nutrition before this activity.');
        }
        
        if (healthMetrics.avg_heart_rate >= 120) {
            insights.push('❤️ High heart rate. This is a physically intense activity.');
        } else if (healthMetrics.avg_heart_rate <= 70) {
            insights.push('💓 Low heart rate. This is a calm, relaxing activity.');
        }
    }
    
    // Time-based insights
    const hour = parseInt(activity.start_time?.split(':')[0] || 12);
    if (hour >= 6 && hour < 9) {
        insights.push('🌅 Morning activity! Great way to start your day productively.');
    } else if (hour >= 20) {
        insights.push('🌙 Evening activity. Make sure it doesn\'t affect your sleep quality.');
    }
    
    if (insights.length === 0) {
        insights.push('📊 Continue tracking this activity to discover patterns and insights.');
    }
    
    return insights.map(insight => `<p class="insight-item">${insight}</p>`).join('');
}

/**
 * Close activity detail modal
 */
function closeActivityDetailModal() {
    const modal = document.getElementById('activity-detail-modal');
    if (modal) {
        modal.classList.remove('active');
        modal.classList.add('hidden');
        showStatusMessage('Activity details closed', 'info');
    }
}

/**
 * Show health metrics from activity detail modal
 */
function showHealthMetricsFromDetail() {
    const displayDiv = document.getElementById('activity-detail-display');
    const activityId = displayDiv.dataset.activityId;
    
    if (activityId) {
        closeActivityDetailModal();
        showHealthMetrics(activityId);
    } else {
        showStatusMessage('No activity selected', 'error');
    }
}

/**
 * Show add activity form
 */
function showAddActivityForm() {
    console.log('➕ Opening add activity form');
    
    // Get the most recent day ID from current state or create a new day for today
    let currentDayId = null;
    
    if (AppState.currentDays.length > 0) {
        // Use the most recent day
        currentDayId = AppState.currentDays[0].day_id;
    } else if (AppState.currentUser) {
        // Create a new day for today
        createNewDayForActivity();
        return;
    } else {
        showStatusMessage('Please select a user first!', 'error');
        return;
    }
    
    // Show the modal
    const modal = document.getElementById('activity-modal');
    if (modal) {
        modal.classList.add('active');
        modal.classList.remove('hidden');
        
        // Reset form
        const form = document.getElementById('activity-creation-form');
        if (form) {
            form.reset();
            // Set the day_id in a hidden field or store it for later use
            form.dataset.dayId = currentDayId;
        }
        
        showStatusMessage('Activity form opened! Fill in the details and submit.', 'info');
    } else {
        showStatusMessage('Error: Activity modal not found', 'error');
    }
}

/**
 * Create a new day for activity creation
 */
async function createNewDayForActivity() {
    try {
        console.log('➕ Creating new day for activity:', AppState.currentUser.user_id);
        
        // Use today's date
        const today = new Date().toISOString().split('T')[0];
        
        // Insert the new day
        const { data, error } = await window.supabaseClient
            .from('days')
            .insert([
                {
                    user_id: AppState.currentUser.user_id,
                    activity_date: today
                }
            ])
            .select()
            .single();
        
        if (error) {
            throw error;
        }
        
        console.log('✅ Day created successfully:', data);
        
        // Add to our state
        AppState.currentDays.unshift({ ...data, activities: [] });
        
        // Now show the activity form with the new day
        showAddActivityForm();
        
    } catch (error) {
        console.error('❌ Error creating day for activity:', error);
        showStatusMessage('Failed to create new day. Please try again.', 'error');
    }
}

/**
 * Create a new day for the current user
 * This function demonstrates how to insert data
 */
async function createNewDay() {
    try {
        console.log('➕ Creating new day for user:', AppState.currentUser.user_id);
        
        // Use today's date
        const today = new Date().toISOString().split('T')[0];
        
        // Check if day already exists for today
        const existingDay = AppState.currentDays.find(d => d.activity_date === today);
        if (existingDay) {
            showStatusMessage('A day already exists for today!', 'warning');
            return;
        }
        
        // Insert the new day
        const { data, error } = await window.supabaseClient
            .from('days')
            .insert([
                {
                    user_id: AppState.currentUser.user_id,
                    activity_date: today
                }
            ])
            .select()
            .single();
        
        if (error) {
            throw error;
        }
        
        console.log('✅ Day created successfully:', data);
        showStatusMessage('New day created successfully!', 'success');
        
        // Add to our state and refresh the table
        AppState.currentDays.unshift({ ...data, activities: [] });
        displayDaysTable();
        
    } catch (error) {
        console.error('❌ Error creating day:', error);
        showStatusMessage('Failed to create new day. Please try again.', 'error');
    }
}

/**
 * Edit a day (placeholder for future implementation)
 * @param {string} dayId - The day ID to edit
 */
function editDay(dayId) {
    console.log('✏️ Editing day:', dayId);
    showStatusMessage('Day editing feature coming soon!', 'info');
    
    // TODO: Implement day editing modal
}

/**
 * Show pattern details (placeholder for future implementation)
 * @param {string} patternId - The pattern ID
 */
function showPatternDetails(patternId) {
    console.log('🔍 Showing pattern details:', patternId);
    
    // Find the pattern in current state
    const pattern = AppState.currentPatterns.find(p => p.pattern_id === patternId);
    if (!pattern) {
        showStatusMessage('Pattern not found', 'error');
        return;
    }
    
    // Show pattern information in a status message for now
    const details = `
        Pattern: ${pattern.pattern_name}
        Type: ${pattern.pattern_type}
        Frequency: ${pattern.frequency} times
        ${pattern.avg_productivity ? `Avg Productivity: ${pattern.avg_productivity}/10` : ''}
        ${pattern.common_time ? `Common Time: ${pattern.common_time}` : ''}
    `;
    
    showStatusMessage(`Pattern Details: ${pattern.pattern_name} (${pattern.pattern_type}, ${pattern.frequency} occurrences)`, 'info');
    
    // TODO: Implement full pattern detail modal in future version
}

// =================================
// EVENT HANDLERS
// =================================

/**
 * Handle user creation form submission
 */
async function handleUserCreation(event) {
    event.preventDefault(); // Prevent form from refreshing the page
    
    // Get form data
    const formData = new FormData(event.target);
    const userData = {
        username: formData.get('username').trim()
    };
    
    // Basic validation
    if (!userData.username) {
        showStatusMessage('Please fill in the username field.', 'error');
        return;
    }
    
    // Create the user
    await createUser(userData);
}

/**
 * Handle user selection button click
 */
async function handleSelectUser() {
    console.log('👤 handleSelectUser called!');
    showStatusMessage('Loading users...', 'info');
    
    try {
        // Load users from database
        await loadUsers();
        
        // Display users (this refreshes the user list)
        displayUsers();
        
        // Switch to user selection view
        console.log('🔄 About to switch to user-selection view');
        await switchView('user-selection');
        console.log('✅ handleSelectUser completed');
    } catch (error) {
        console.error('❌ Error in handleSelectUser:', error);
        showStatusMessage('Failed to load users. Please try again.', 'error');
    }
}

/**
 * Handle create user button click
 */
function handleCreateUser() {
    console.log('➕ handleCreateUser called!');
    
    try {
        // Clear the form
        const form = document.getElementById('user-creation-form');
        if (form) {
            form.reset();
            console.log('✅ Form reset');
        } else {
            console.error('❌ User creation form not found!');
        }
        
        // Switch to user creation view
        console.log('🔄 About to switch to user-creation view');
        switchView('user-creation');
        console.log('✅ handleCreateUser completed');
    } catch (error) {
        console.error('❌ Error in handleCreateUser:', error);
        showStatusMessage('Failed to open user creation. Please try again.', 'error');
    }
}

// =================================
// INITIALIZATION
// =================================

/**
 * Test Supabase connection and basic operations
 */
async function testSupabaseConnection() {
    try {
        console.log('🔍 Testing Supabase connection...');
        
        // Test basic connection
        const { data, error } = await window.supabaseClient
            .from('users')
            .select('count')
            .single();
        
        if (error) {
            console.error('❌ Supabase connection error:', error);
            showStatusMessage('Database connection failed. Check your configuration.', 'error');
            return false;
        }
        
        console.log('✅ Supabase connection successful!');
        showStatusMessage('Database connected successfully!', 'success');
        return true;
        
    } catch (error) {
        console.error('❌ Connection test failed:', error);
        showStatusMessage('Database connection test failed.', 'error');
        return false;
    }
}

/**
 * Initialize the application when DOM is loaded
 * This function demonstrates how to start the application
 */
async function initializeApp() {
    console.log('🚀 Initializing UpEye Application...');
    
    // Test Supabase connection first
    const isConnected = await testSupabaseConnection();
    if (!isConnected) {
        console.error('❌ Cannot proceed without database connection');
        return;
    }
    
    // Set up event listeners
    setupEventListeners();
    
    // Load initial data
    await loadUsers();
    
    // Show home view
    await switchView('home');
    
    console.log('✅ UpEye Application initialized successfully!');
}

/**
 * Set up all event listeners for the application
 * This function demonstrates how to handle user interactions
 */
function setupEventListeners() {
    console.log('🎯 Setting up event listeners...');
    
    // Navigation buttons
    const selectBtn = document.getElementById('select-user-btn');
    const createBtn = document.getElementById('create-user-btn');
    console.log('🔍 Found buttons:', { selectBtn, createBtn });
    
    if (selectBtn) {
        console.log('✅ Select user button found!');
        selectBtn.addEventListener('click', handleSelectUser);
    } else {
        console.error('❌ Select user button not found!');
    }
    
    if (createBtn) {
        console.log('✅ Create user button found!');
        createBtn.addEventListener('click', handleCreateUser);
    } else {
        console.error('❌ Create user button not found!');
    }
    
    // Pattern length buttons
    const pattern2Btn = document.getElementById('pattern-2-btn');
    const pattern3Btn = document.getElementById('pattern-3-btn');
    const pattern4Btn = document.getElementById('pattern-4-btn');
    const pattern1Btn = document.getElementById('pattern-1-btn');
    
    if (pattern2Btn) {
        pattern2Btn.addEventListener('click', () => handlePatternLengthSelection(2));
    }
    
    if (pattern3Btn) {
        pattern3Btn.addEventListener('click', () => handlePatternLengthSelection(3));
    }
    
    if (pattern4Btn) {
        pattern4Btn.addEventListener('click', () => handlePatternLengthSelection(4));
    }
    
    if (pattern1Btn) {
        pattern1Btn.addEventListener('click', () => handlePatternLengthSelection(1));
    }
    
    document.getElementById('cancel-creation').addEventListener('click', async () => { await switchView('home'); });
    
    // Calendar navigation
    const backToSelection = document.getElementById('back-to-selection');
    if (backToSelection) backToSelection.addEventListener('click', async () => { await switchView('user-selection'); });
    
    const backToDays = document.getElementById('back-to-days');
    if (backToDays) backToDays.addEventListener('click', async () => { await switchView('days-table'); });
    
    const backToDaysFromActivity = document.getElementById('back-to-days-from-activity');
    if (backToDaysFromActivity) backToDaysFromActivity.addEventListener('click', async () => { await switchView('days-table'); });
    
    const prevMonthBtn = document.getElementById('prev-month');
    if (prevMonthBtn) prevMonthBtn.addEventListener('click', previousMonth);
    
    const nextMonthBtn = document.getElementById('next-month');
    if (nextMonthBtn) nextMonthBtn.addEventListener('click', nextMonth);
    
    const currentMonthBtn = document.getElementById('current-month-btn');
    if (currentMonthBtn) currentMonthBtn.addEventListener('click', goToCurrentMonth);
    
    // Pattern diagnostics
    const patternDiagnosticsBtn = document.getElementById('pattern-diagnostics-btn');
    if (patternDiagnosticsBtn) patternDiagnosticsBtn.addEventListener('click', handlePatternDiagnostics);
    
    const patternLogBtn = document.getElementById('pattern-log-btn');
    if (patternLogBtn) patternLogBtn.addEventListener('click', () => switchPatternView('log'));
    
    const patternResultsBtn = document.getElementById('pattern-results-btn');
    if (patternResultsBtn) patternResultsBtn.addEventListener('click', () => switchPatternView('results'));
    
    // Export button
    const exportBtn = document.getElementById('export-data-btn');
    if (exportBtn) exportBtn.addEventListener('click', handleExportData);
    
    // Days table actions
    const addNewDayBtn = document.getElementById('add-new-day-btn');
    if (addNewDayBtn) addNewDayBtn.addEventListener('click', createNewDay);
    
    // Activity actions
    const addActivityBtn = document.getElementById('add-activity-btn');
    if (addActivityBtn) addActivityBtn.addEventListener('click', showAddActivityForm);
    
    // Activity form submission
    const activityForm = document.getElementById('activity-creation-form');
    if (activityForm) {
        activityForm.addEventListener('submit', handleActivityCreation);
    }
    
    // User creation form submission
    const userCreationForm = document.getElementById('user-creation-form');
    if (userCreationForm) {
        userCreationForm.addEventListener('submit', handleUserCreation);
    }
    
    console.log('✅ Event listeners set up successfully!');
}

// =================================
// GLOBAL FUNCTIONS (for onclick handlers)
// =================================

// Make functions available globally for onclick handlers
window.selectUser = selectUser;
console.log('🔍 Checking if viewDayDetails is defined:', typeof viewDayDetails);
window.viewDayDetails = viewDayDetails;
window.viewActivityDetails = viewActivityDetails;
window.showActivityFullDetails = showActivityFullDetails;
window.closeActivityDetailModal = closeActivityDetailModal;
window.showHealthMetricsFromDetail = showHealthMetricsFromDetail;
window.editDay = editDay;
window.selectCalendarDay = selectCalendarDay;
window.previousMonth = previousMonth;
window.nextMonth = nextMonth;
window.goToCurrentMonth = goToCurrentMonth;
window.showAddActivityForm = showAddActivityForm;
window.closeActivityModal = closeActivityModal;
window.handleActivityCreation = handleActivityCreation;
window.showHealthMetrics = showHealthMetrics;
console.log('🔍 showHealthMetrics exported to window:', typeof window.showHealthMetrics);
window.closeHealthMetricsModal = closeHealthMetricsModal;
window.generateRandomHealthMetrics = generateRandomHealthMetrics;
window.handlePatternDiagnostics = handlePatternDiagnostics;
window.switchPatternView = switchPatternView;
window.showPatternDetails = showPatternDetails;
window.handleUserCreation = handleUserCreation;
window.createNewDayForActivity = createNewDayForActivity;
window.calculateDuration = calculateDuration;
window.generateContextualHealthMetrics = generateContextualHealthMetrics;
window.analyzeActivityPatterns = analyzeActivityPatterns;
window.analyzeActivityPattern = analyzeActivityPattern;
window.analyzeTimePatterns = analyzeTimePatterns;
window.analyzeHealthPatterns = analyzeHealthPatterns;
window.getPatternTypeIcon = getPatternTypeIcon;
window.getFrequencyText = getFrequencyText;
window.getPatternColor = getPatternColor;
window.displayActivityDetail = displayActivityDetail;
window.generateActivityInsights = generateActivityInsights;
window.exportUserData = exportUserData;
window.exportPatternAnalysis = exportPatternAnalysis;
window.handleExportData = handleExportData;
window.generateCSVExport = generateCSVExport;
window.downloadCSV = downloadCSV;
window.downloadJSON = downloadJSON;

// =================================
// DOM READY EVENT
// =================================

// Wait for DOM to be ready before initializing
document.addEventListener('DOMContentLoaded', async function() {
    console.log('🚀 DOM Content Loaded - Starting UpEye Application...');
    await initializeApp();
});
