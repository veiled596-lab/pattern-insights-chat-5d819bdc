-- =================================
-- CHECK ACTIVITIES TABLE SCHEMA
-- =================================

-- Get column names and types for activities table
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'activities' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- Get sample data to see actual structure
SELECT * FROM activities LIMIT 5;
