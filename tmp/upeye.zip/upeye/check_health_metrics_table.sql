-- =================================
-- CHECK HEALTH_METRICS TABLE
-- =================================

-- Check if health_metrics table exists
SELECT 
    table_name,
    column_name,
    data_type
FROM information_schema.columns 
WHERE table_name = 'health_metrics' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- Check if there's any data in health_metrics table
SELECT 
    COUNT(*) as total_records,
    COUNT(DISTINCT activity_id) as activities_with_metrics
FROM health_metrics
LIMIT 5;

-- Sample health metrics data
SELECT 
    hm.*,
    a.activity_name
FROM health_metrics hm
JOIN activities a ON hm.activity_id = a.activity_id
LIMIT 10;
