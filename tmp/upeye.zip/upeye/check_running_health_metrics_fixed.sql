-- Check health metrics for the most recent running activity (without created_at)
SELECT 
    a.activity_name,
    a.activity_id,
    a.start_time,
    a.end_time,
    d.activity_date,
    h.avg_heart_rate,
    h.energy_level,
    h.stress_level,
    h.hydration_level,
    h.sleep_quality
FROM activities a
JOIN days d ON a.day_id = d.day_id
LEFT JOIN health_metrics h ON a.activity_id = h.activity_id
WHERE a.activity_name ILIKE '%running%' 
ORDER BY d.activity_date DESC, a.start_time DESC
LIMIT 5;

-- Check all recent health metrics entries (without created_at)
SELECT 
    activity_id,
    avg_heart_rate,
    energy_level,
    stress_level,
    hydration_level,
    sleep_quality
FROM health_metrics 
ORDER BY activity_id DESC
LIMIT 10;

-- Count total health metrics entries
SELECT COUNT(*) as total_health_metrics FROM health_metrics;

-- Check the exact structure of health_metrics table
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'health_metrics'
ORDER BY ordinal_position;
