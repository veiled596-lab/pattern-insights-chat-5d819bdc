-- =================================
-- CHECK SEQUENTIAL PATTERNS IN SUPABASE
-- =================================

-- First, let's see all activities with their dates and times
SELECT 
    d.activity_date,
    a.activity_name,
    a.start_time,
    a.end_time,
    ROW_NUMBER() OVER (ORDER BY d.activity_date, a.start_time) as sequence_num
FROM days d
JOIN activities a ON d.day_id = a.day_id
WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
ORDER BY d.activity_date, a.start_time;

-- Check 2-activity patterns (what follows what)
WITH activity_sequences AS (
    SELECT 
        d.activity_date,
        a.activity_name,
        a.start_time,
        LEAD(a.activity_name, 1) OVER (ORDER BY d.activity_date, a.start_time) as next_activity,
        LEAD(a.activity_name, 2) OVER (ORDER BY d.activity_date, a.start_time) as third_activity,
        LEAD(a.activity_name, 3) OVER (ORDER BY d.activity_date, a.start_time) as fourth_activity
    FROM days d
    JOIN activities a ON d.day_id = a.day_id
    WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
    AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
)
-- 2-activity patterns
SELECT 
    activity_name || ' → ' || next_activity as pattern_2_activities,
    COUNT(*) as frequency
FROM activity_sequences
WHERE next_activity IS NOT NULL
GROUP BY activity_name, next_activity
HAVING COUNT(*) >= 2
ORDER BY frequency DESC;

-- 3-activity patterns
WITH activity_sequences AS (
    SELECT 
        d.activity_date,
        a.activity_name,
        a.start_time,
        LEAD(a.activity_name, 1) OVER (ORDER BY d.activity_date, a.start_time) as next_activity,
        LEAD(a.activity_name, 2) OVER (ORDER BY d.activity_date, a.start_time) as third_activity
    FROM days d
    JOIN activities a ON d.day_id = a.day_id
    WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
    AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
)
SELECT 
    activity_name || ' → ' || next_activity || ' → ' || third_activity as pattern_3_activities,
    COUNT(*) as frequency
FROM activity_sequences
WHERE next_activity IS NOT NULL AND third_activity IS NOT NULL
GROUP BY activity_name, next_activity, third_activity
HAVING COUNT(*) >= 2
ORDER BY frequency DESC;

-- 4-activity patterns
WITH activity_sequences AS (
    SELECT 
        d.activity_date,
        a.activity_name,
        a.start_time,
        LEAD(a.activity_name, 1) OVER (ORDER BY d.activity_date, a.start_time) as next_activity,
        LEAD(a.activity_name, 2) OVER (ORDER BY d.activity_date, a.start_time) as third_activity,
        LEAD(a.activity_name, 3) OVER (ORDER BY d.activity_date, a.start_time) as fourth_activity
    FROM days d
    JOIN activities a ON d.day_id = a.day_id
    WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
    AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
)
SELECT 
    activity_name || ' → ' || next_activity || ' → ' || third_activity || ' → ' || fourth_activity as pattern_4_activities,
    COUNT(*) as frequency
FROM activity_sequences
WHERE next_activity IS NOT NULL AND third_activity IS NOT NULL AND fourth_activity IS NOT NULL
GROUP BY activity_name, next_activity, third_activity, fourth_activity
HAVING COUNT(*) >= 2
ORDER BY frequency DESC;
