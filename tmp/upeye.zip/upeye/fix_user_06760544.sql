-- =================================
-- FIX USER 06760544 - ADD MISSING FEBRUARY ACTIVITIES
-- =================================

-- First, ensure all February days exist for this user
INSERT INTO days (user_id, activity_date)
SELECT 
    '06760544-c0bb-4755-8379-abf278aed684' as user_id,
    date::date as activity_date
FROM generate_series('2026-02-01'::date, '2026-02-28'::date, '1 day'::interval) as date
WHERE date::date NOT IN (
    SELECT activity_date 
    FROM days 
    WHERE user_id = '06760544-c0bb-4755-8379-abf278aed684'
    AND activity_date BETWEEN '2026-02-01' AND '2026-02-28'
);

-- Now insert 5 activities per day for all February days
INSERT INTO activities (
    day_id, 
    activity_name, 
    start_time, 
    end_time, 
    productivity_score, 
    satisfaction_score
)
SELECT 
    d.day_id,
    activity_name,
    start_time,
    end_time,
    productivity_score,
    satisfaction_score
FROM days d
CROSS JOIN (
    -- Generate 5 activities per day
    SELECT 
        '2026-02-01'::date + generate_series(0, 27, 1) * INTERVAL '1 day' as activity_date,
        generate_series(1, 5, 1) as activity_num,
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as base_activity,
        (ARRAY['08:00:00', '09:00:00', '10:00:00', '11:00:00', '14:00:00'])[FLOOR(RANDOM() * 5)] as start_time,
        (ARRAY['09:00:00', '10:00:00', '11:00:00', '12:00:00', '15:00:00'])[FLOOR(RANDOM() * 5)] as end_time,
        FLOOR(RANDOM() * 5) + 5 as productivity_score,
        FLOOR(RANDOM() * 5) + 5 as satisfaction_score
) activities
WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
AND d.activity_date = activities.activity_date
AND NOT EXISTS (
    SELECT 1 FROM activities a 
    WHERE a.day_id = d.day_id 
    LIMIT 5
    OFFSET (activities.activity_num - 1)
)
ON CONFLICT DO NOTHING;
