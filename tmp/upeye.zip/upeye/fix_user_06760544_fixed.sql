-- =================================
-- FIX USER 06760544 - FIXED TIME VALUES
-- =================================

-- First, ensure all February days exist for this user
INSERT INTO days (user_id, activity_date)
SELECT 
    '06760544-c0bb-4755-8379-abf278aed684' as user_id,
    date::date as activity_date
FROM generate_series('2026-02-01'::date, '2026-02-28'::date, '1 day'::interval) as date
ON CONFLICT (user_id, activity_date) DO NOTHING;

-- Now insert activities with proper time handling
WITH all_days AS (
    SELECT day_id, activity_date
    FROM days
    WHERE user_id = '06760544-c0bb-4755-8379-abf278aed684'
    AND activity_date BETWEEN '2026-02-01' AND '2026-02-28'
),
activity_data AS (
    SELECT 
        day_id,
        COALESCE((ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10) + 1], 'Work') as activity_name,
        CASE FLOOR(RANDOM() * 5)
            WHEN 0 THEN '08:00:00'::time
            WHEN 1 THEN '09:00:00'::time
            WHEN 2 THEN '10:00:00'::time
            WHEN 3 THEN '11:00:00'::time
            WHEN 4 THEN '14:00:00'::time
        END as start_time,
        CASE FLOOR(RANDOM() * 5)
            WHEN 0 THEN '09:00:00'::time
            WHEN 1 THEN '10:00:00'::time
            WHEN 2 THEN '11:00:00'::time
            WHEN 3 THEN '12:00:00'::time
            WHEN 4 THEN '15:00:00'::time
        END as end_time,
        FLOOR(RANDOM() * 5) + 5 as productivity_score,
        FLOOR(RANDOM() * 5) + 5 as satisfaction_score
    FROM all_days
    CROSS JOIN generate_series(1, 5) -- 5 activities per day
)
INSERT INTO activities (day_id, activity_name, start_time, end_time, productivity_score, satisfaction_score)
SELECT day_id, activity_name, start_time, end_time, productivity_score, satisfaction_score
FROM activity_data
WHERE start_time IS NOT NULL AND end_time IS NOT NULL
ON CONFLICT DO NOTHING;
