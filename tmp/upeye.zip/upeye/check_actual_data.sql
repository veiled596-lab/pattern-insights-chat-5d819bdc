-- =================================
-- CHECK WHAT'S ACTUALLY IN THE DATABASE
-- =================================

-- Check total activities by user
SELECT 
    u.user_id,
    u.username,
    COUNT(a.activity_id) as total_activities,
    COUNT(DISTINCT d.activity_date) as days_with_activities,
    MIN(d.activity_date) as earliest_date,
    MAX(d.activity_date) as latest_date
FROM users u
LEFT JOIN days d ON u.user_id = d.user_id
LEFT JOIN activities a ON d.day_id = a.day_id
GROUP BY u.user_id, u.username
ORDER BY total_activities DESC;

-- Check activities by date
SELECT 
    d.activity_date,
    COUNT(a.activity_id) as activity_count,
    STRING_AGG(a.activity_name, ', ' ORDER BY a.activity_name) as activities
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.activity_date
ORDER BY d.activity_date;

-- Check sample activities
SELECT 
    d.activity_date,
    a.activity_name,
    a.start_time,
    a.end_time,
    a.productivity_score,
    a.satisfaction_score
FROM days d
JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
ORDER BY d.activity_date, a.start_time
LIMIT 20;

-- Check if there are any activities outside February
SELECT 
    d.activity_date,
    COUNT(a.activity_id) as activity_count
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date NOT BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.activity_date
ORDER BY d.activity_date;
