-- =================================
-- CHECK ACTIVITIES FOR 2026-02-12
-- =================================

-- Check if 2026-02-12 exists and has activities
SELECT 
    d.day_id,
    d.user_id,
    d.activity_date,
    COUNT(a.activity_id) as activity_count,
    STRING_AGG(a.activity_name, ', ' ORDER BY a.start_time) as activity_names
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date = '2026-02-12'
GROUP BY d.day_id, d.user_id, d.activity_date
ORDER BY d.activity_date;

-- Check all users who have activities on 2026-02-12
SELECT DISTINCT
    d.user_id,
    u.username,
    d.activity_date,
    COUNT(a.activity_id) as activity_count
FROM days d
JOIN activities a ON d.day_id = a.day_id
JOIN users u ON d.user_id = u.user_id
WHERE d.activity_date = '2026-02-12'
GROUP BY d.user_id, u.username, d.activity_date;

-- Check sample activities for 2026-02-12
SELECT 
    d.activity_date,
    d.user_id,
    u.username,
    a.activity_name,
    a.start_time,
    a.end_time,
    a.productivity_score,
    a.satisfaction_score
FROM days d
JOIN activities a ON d.day_id = a.day_id
JOIN users u ON d.user_id = u.user_id
WHERE d.activity_date = '2026-02-12'
ORDER BY a.start_time;
