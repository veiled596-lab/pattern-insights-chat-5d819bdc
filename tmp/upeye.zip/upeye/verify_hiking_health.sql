-- =================================
-- VERIFY HIKING ACTIVITY HEALTH METRICS
-- =================================

-- Check if the hiking activity was created and has health metrics
SELECT 
    a.activity_name,
    a.activity_id,
    a.start_time,
    a.end_time,
    a.productivity_score,
    a.satisfaction_score,
    d.activity_date,
    h.metric_id,
    h.avg_heart_rate,
    h.stress_level,
    h.energy_level,
    CASE 
        WHEN h.activity_id IS NOT NULL THEN '✅ Health metrics generated'
        ELSE '❌ No health metrics'
    END as health_status
FROM activities a
JOIN days d ON a.day_id = d.day_id
LEFT JOIN health_metrics h ON a.activity_id = h.activity_id
WHERE a.activity_name = 'hiking' 
AND d.activity_date = CURRENT_DATE
ORDER BY a.start_time DESC;

-- If you want to see the most recent health metrics entry
SELECT 
    activity_id,
    avg_heart_rate,
    stress_level,
    energy_level,
    created_at
FROM health_metrics 
ORDER BY metric_id DESC
LIMIT 1;
