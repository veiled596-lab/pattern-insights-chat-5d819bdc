-- =================================
-- BULK INSERT FEBRUARY ACTIVITIES FOR PATTERN GENERATION
-- =================================

-- First, let's see what users exist to pick one for the activities
SELECT user_id, username FROM users LIMIT 1;

-- Then insert 5 activities per day for February 2026
-- This will create meaningful patterns for the pattern diagnostics

-- Insert activities for each day in February 2026
WITH feb_dates AS (
    SELECT generate_series(
        '2026-02-01'::date, 
        '2026-02-28'::date, 
        '1 day'::interval
    )::date as activity_date
),
activities_to_insert AS (
    SELECT 
        d.activity_date,
        u.user_id,  -- Use the first user found
        CASE 
            WHEN EXTRACT(DOW FROM d.activity_date) IN (0, 6) THEN 'Weekend Rest'
            WHEN EXTRACT(DOW FROM d.activity_date) = 1 THEN 'Morning Exercise'
            WHEN EXTRACT(DOW FROM d.activity_date) = 2 THEN 'Work Meeting'
            WHEN EXTRACT(DOW FROM d.activity_date) = 3 THEN 'Creative Work'
            WHEN EXTRACT(DOW FROM d.activity_date) = 4 THEN 'Physical Activity'
            WHEN EXTRACT(DOW FROM d.activity_date) = 5 THEN 'Social Time'
        END as activity_name,
        CASE 
            WHEN EXTRACT(DOW FROM d.activity_date) IN (0, 6) THEN '10:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 1 THEN '06:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 2 THEN '09:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 3 THEN '10:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 4 THEN '17:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 5 THEN '19:00:00'
        END as start_time,
        CASE 
            WHEN EXTRACT(DOW FROM d.activity_date) IN (0, 6) THEN '11:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 1 THEN '07:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 2 THEN '10:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 3 THEN '12:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 4 THEN '18:00:00'
            WHEN EXTRACT(DOW FROM d.activity_date) = 5 THEN '20:00:00'
        END as end_time,
        CASE 
            WHEN EXTRACT(DOW FROM d.activity_date) IN (0, 6) THEN 7
            WHEN EXTRACT(DOW FROM d.activity_date) = 1 THEN 9
            WHEN EXTRACT(DOW FROM d.activity_date) = 2 THEN 6
            WHEN EXTRACT(DOW FROM d.activity_date) = 3 THEN 8
            WHEN EXTRACT(DOW FROM d.activity_date) = 4 THEN 9
            WHEN EXTRACT(DOW FROM d.activity_date) = 5 THEN 8
        END as productivity_score,
        CASE 
            WHEN EXTRACT(DOW FROM d.activity_date) IN (0, 6) THEN 9
            WHEN EXTRACT(DOW FROM d.activity_date) = 1 THEN 8
            WHEN EXTRACT(DOW FROM d.activity_date) = 2 THEN 5
            WHEN EXTRACT(DOW FROM d.activity_date) = 3 THEN 7
            WHEN EXTRACT(DOW FROM d.activity_date) = 4 THEN 9
            WHEN EXTRACT(DOW FROM d.activity_date) = 5 THEN 9
        END as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
),
-- Generate 5 activities per day with variations
multi_activities AS (
    SELECT 
        activity_date,
        user_id,
        activity_name,
        start_time,
        end_time,
        productivity_score,
        satisfaction_score
    FROM activities_to_insert
    
    UNION ALL
    
    SELECT 
        activity_date,
        user_id,
        activity_name || ' - Task 2' as activity_name,
        (EXTRACT(HOUR FROM start_time::time) + 1 || ':00:00')::time as start_time,
        (EXTRACT(HOUR FROM end_time::time) + 1 || ':00:00')::time as end_time,
        GREATEST(productivity_score - 1, 1) as productivity_score,
        GREATEST(satisfaction_score - 1, 1) as satisfaction_score
    FROM activities_to_insert
    
    UNION ALL
    
    SELECT 
        activity_date,
        user_id,
        activity_name || ' - Task 3' as activity_name,
        (EXTRACT(HOUR FROM start_time::time) + 2 || ':00:00')::time as start_time,
        (EXTRACT(HOUR FROM end_time::time) + 2 || ':00:00')::time as end_time,
        GREATEST(productivity_score - 2, 1) as productivity_score,
        GREATEST(satisfaction_score - 2, 1) as satisfaction_score
    FROM activities_to_insert
    
    UNION ALL
    
    SELECT 
        activity_date,
        user_id,
        activity_name || ' - Task 4' as activity_name,
        (EXTRACT(HOUR FROM start_time::time) + 3 || ':00:00')::time as start_time,
        (EXTRACT(HOUR FROM end_time::time) + 3 || ':00:00')::time as end_time,
        GREATEST(productivity_score - 1, 1) as productivity_score,
        satisfaction_score + 1 as satisfaction_score
    FROM activities_to_insert
    
    UNION ALL
    
    SELECT 
        activity_date,
        user_id,
        'Break Time' as activity_name,
        '14:00:00'::time as start_time,
        '14:30:00'::time as end_time,
        5 as productivity_score,
        8 as satisfaction_score
    FROM activities_to_insert
)
-- Insert days first (if they don't exist)
INSERT INTO days (user_id, activity_date)
SELECT DISTINCT user_id, activity_date 
FROM multi_activities
ON CONFLICT (user_id, activity_date) DO NOTHING;

-- Insert all activities
INSERT INTO activities (day_id, activity_name, start_time, end_time, productivity_score, satisfaction_score)
SELECT 
    d.day_id,
    ma.activity_name,
    ma.start_time,
    ma.end_time,
    ma.productivity_score,
    ma.satisfaction_score
FROM multi_activities ma
JOIN days d ON ma.activity_date = d.activity_date AND ma.user_id = d.user_id;

-- Verify the insertions
SELECT 
    d.activity_date,
    COUNT(a.activity_id) as activity_count,
    STRING_AGG(a.activity_name, ', ' ORDER BY a.start_time) as activities
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.activity_date
ORDER BY d.activity_date;
