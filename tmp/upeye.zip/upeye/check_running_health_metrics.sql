-- Check health metrics for the most recent running activity
SELECT 
    a.activity_name,
    a.activity_id,
    a.start_time,
    a.end_time,
    d.activity_date,
    h.avg_heart_rate,
    h.energy_level,
    h.stress_level,
    h.hydration_level,
    h.sleep_quality,
    h.created_at
FROM activities a
JOIN days d ON a.day_id = d.day_id
LEFT JOIN health_metrics h ON a.activity_id = h.activity_id
WHERE a.activity_name ILIKE '%running%' 
ORDER BY d.activity_date DESC, a.start_time DESC
LIMIT 5;

-- Also check all recent health metrics entries
SELECT 
    activity_id,
    avg_heart_rate,
    energy_level,
    stress_level,
    hydration_level,
    sleep_quality,
    created_at
FROM health_metrics 
ORDER BY created_at DESC
LIMIT 10;

-- Count total health metrics entries
SELECT COUNT(*) as total_health_metrics FROM health_metrics;
