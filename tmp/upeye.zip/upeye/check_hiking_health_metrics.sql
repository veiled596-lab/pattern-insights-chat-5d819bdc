-- =================================
-- CHECK FOR NEW HIKING ACTIVITY HEALTH METRICS
-- =================================

-- Find the hiking activity created today
SELECT 
    a.activity_name,
    a.activity_id,
    a.start_time,
    a.end_time,
    d.activity_date,
    h.metric_id,
    h.avg_heart_rate,
    h.stress_level,
    h.energy_level
FROM activities a
JOIN days d ON a.day_id = d.day_id
LEFT JOIN health_metrics h ON a.activity_id = h.activity_id
WHERE a.activity_name ILIKE '%hiking%' 
AND d.activity_date = CURRENT_DATE
ORDER BY a.start_time DESC;

-- Check all activities created today
SELECT 
    a.activity_name,
    a.activity_id,
    a.start_time,
    a.end_time,
    d.activity_date,
    h.avg_heart_rate,
    h.stress_level,
    h.energy_level,
    CASE 
        WHEN h.activity_id IS NOT NULL THEN 'Health metrics exist'
        ELSE 'No health metrics'
    END as health_status
FROM activities a
JOIN days d ON a.day_id = d.day_id
LEFT JOIN health_metrics h ON a.activity_id = h.activity_id
WHERE d.activity_date = CURRENT_DATE
ORDER BY a.start_time DESC;
