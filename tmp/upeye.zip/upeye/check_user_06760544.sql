-- =================================
-- CHECK IF USER 06760544 HAS FEBRUARY ACTIVITIES
-- =================================

-- Check total activities for user 06760544-c0bb-4755-8379-abf278aed684 in February
SELECT 
    COUNT(a.activity_id) as total_activities,
    COUNT(DISTINCT d.activity_date) as days_with_activities,
    MIN(d.activity_date) as earliest_date,
    MAX(d.activity_date) as latest_date
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.user_id;

-- Check which dates exist for this user in February
SELECT 
    d.activity_date,
    COUNT(a.activity_id) as activity_count,
    STRING_AGG(a.activity_name, ', ' ORDER BY a.start_time) as activity_names
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.user_id = '06760544-c0bb-4755-8379-abf278aed684'
AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.activity_date
ORDER BY d.activity_date;

-- Compare with user that has activities
SELECT 
    'dc919d89-05d3-4373-bda7-5fd6f020deb5' as user_with_activities,
    COUNT(a.activity_id) as total_activities,
    COUNT(DISTINCT d.activity_date) as days_with_activities
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.user_id = 'dc919d89-05d3-4373-bda7-5fd6f020deb5'
AND d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.user_id;
