-- =================================
-- 5 ACTIVITIES PER DAY FOR ALL FEBRUARY (SIMPLE VERSION)
-- =================================

-- Generate all dates in February 2026
WITH feb_dates AS (
    SELECT generate_series(
        '2026-02-01'::date, 
        '2026-02-28'::date, 
        '1 day'::interval
    )::date as activity_date
),
-- Generate all 5 activities per day in one go
all_activities AS (
    SELECT 
        d.activity_date,
        u.user_id,
        -- Activity 1
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as activity_name,
        ((FLOOR(RANDOM() * 16) + 6)::text || ':00:00')::time as start_time,
        ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time as end_time,
        FLOOR(RANDOM() * 10 + 1) as productivity_score,
        FLOOR(RANDOM() * 10 + 1) as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
    
    UNION ALL
    
    SELECT 
        d.activity_date,
        u.user_id,
        -- Activity 2
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as activity_name,
        ((FLOOR(RANDOM() * 16) + 6)::text || ':00:00')::time as start_time,
        ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time as end_time,
        FLOOR(RANDOM() * 10 + 1) as productivity_score,
        FLOOR(RANDOM() * 10 + 1) as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
    
    UNION ALL
    
    SELECT 
        d.activity_date,
        u.user_id,
        -- Activity 3
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as activity_name,
        ((FLOOR(RANDOM() * 16) + 6)::text || ':00:00')::time as start_time,
        ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time as end_time,
        FLOOR(RANDOM() * 10 + 1) as productivity_score,
        FLOOR(RANDOM() * 10 + 1) as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
    
    UNION ALL
    
    SELECT 
        d.activity_date,
        u.user_id,
        -- Activity 4
        (ARRAY['Running', 'Gym Workout', 'Yoga', 'Work', 'Meeting', 'Reading', 'Cooking', 'Walking', 'Meditation', 'Social Time'])[FLOOR(RANDOM() * 10)] as activity_name,
        ((FLOOR(RANDOM() * 16) + 6)::text || ':00:00')::time as start_time,
        ((FLOOR(RANDOM() * 16) + 6 + 3)::text || ':00:00')::time as end_time,
        FLOOR(RANDOM() * 10 + 1) as productivity_score,
        FLOOR(RANDOM() * 10 + 1) as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
    
    UNION ALL
    
    SELECT 
        d.activity_date,
        u.user_id,
        -- Activity 5 (Break Time)
        'Break Time' as activity_name,
        '14:00:00'::time as start_time,
        '14:30:00'::time as end_time,
        5 as productivity_score,
        8 as satisfaction_score
    FROM feb_dates d
    CROSS JOIN (SELECT user_id FROM users LIMIT 1) u
)
-- Insert all days first
INSERT INTO days (user_id, activity_date)
SELECT DISTINCT user_id, activity_date 
FROM all_activities
ON CONFLICT (user_id, activity_date) DO NOTHING;

-- Insert all activities
INSERT INTO activities (day_id, activity_name, start_time, end_time, productivity_score, satisfaction_score)
SELECT 
    d.day_id,
    aa.activity_name,
    aa.start_time,
    aa.end_time,
    aa.productivity_score,
    aa.satisfaction_score
FROM all_activities aa
JOIN days d ON aa.activity_date = d.activity_date AND aa.user_id = d.user_id;

-- Show summary of what was created
SELECT 
    d.activity_date,
    COUNT(a.activity_id) as activity_count,
    STRING_AGG(DISTINCT a.activity_name, ', ' ORDER BY a.activity_name) as unique_activities
FROM days d
LEFT JOIN activities a ON d.day_id = a.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28'
GROUP BY d.activity_date
ORDER BY d.activity_date;

-- Total count verification
SELECT 
    COUNT(*) as total_activities,
    COUNT(DISTINCT activity_name) as unique_activity_types,
    COUNT(DISTINCT d.activity_date) as days_with_activities
FROM activities a
JOIN days d ON a.day_id = d.day_id
WHERE d.activity_date BETWEEN '2026-02-01' AND '2026-02-28';
