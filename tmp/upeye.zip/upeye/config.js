// Supabase Configuration
// IMPORTANT: Replace these with your actual Supabase project details
const SUPABASE_URL = 'https://bwydpxwphytucmorxtel.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ3eWRweHdwaHl0dWNtb3J4dGVsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA0Mzc5NzIsImV4cCI6MjA4NjAxMzk3Mn0.-XAxEXqVPaejdrzDvgwPsQHoxKjzPTduf8dBqXlLWLM';

// Self-contained mode - works without Supabase
const USE_MOCK_DATA = false; // Set to true for demo mode without database

// Mock data for demo mode
const MOCK_DATA = {
    users: [
        { user_id: 'demo-user-1', username: 'Demo User', created_at: new Date().toISOString() }
    ],
    activities: [
        // Generate sample activities with health metrics
        { activity_id: '1', activity_name: 'Walking', day_id: '1', start_time: '08:00', productivity_score: 7, satisfaction_score: 8, health_metrics: { avg_heart_rate: 75, stress_level: 3, energy_level: 6, hydration_level: 7, sleep_quality: 8 } },
        { activity_id: '2', activity_name: 'Work', day_id: '1', start_time: '09:00', productivity_score: 8, satisfaction_score: 7, health_metrics: { avg_heart_rate: 80, stress_level: 4, energy_level: 7, hydration_level: 6, sleep_quality: 7 } },
        { activity_id: '3', activity_name: 'Yoga', day_id: '1', start_time: '17:00', productivity_score: 6, satisfaction_score: 9, health_metrics: { avg_heart_rate: 70, stress_level: 2, energy_level: 8, hydration_level: 8, sleep_quality: 9 } }
    ],
    days: [
        { day_id: '1', user_id: 'demo-user-1', activity_date: '2026-02-20' }
    ]
};

// Initialize Supabase client or mock client
let supabaseClient;

if (USE_MOCK_DATA) {
    // Mock client for demo mode
    supabaseClient = {
        from: (table) => ({
            select: (columns) => ({
                in: (column, values) => ({
                    data: MOCK_DATA[table] || [],
                    error: null
                }),
                eq: (column, value) => ({
                    data: MOCK_DATA[table]?.filter(item => item[column] === value) || [],
                    error: null
                })
            })
        })
    };
} else {
    // Real Supabase client
    try {
        supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } catch (error) {
        console.error('Failed to initialize Supabase, falling back to mock data:', error);
        // Fallback to mock mode
        supabaseClient = {
            from: (table) => ({
                select: (columns) => ({
                    in: (column, values) => ({
                        data: MOCK_DATA[table] || [],
                        error: null
                    }),
                    eq: (column, value) => ({
                        data: MOCK_DATA[table]?.filter(item => item[column] === value) || [],
                        error: null
                    })
                })
            })
        };
    }
}

// Export for use in other files
window.supabaseClient = supabaseClient;
window.USE_MOCK_DATA = USE_MOCK_DATA;
