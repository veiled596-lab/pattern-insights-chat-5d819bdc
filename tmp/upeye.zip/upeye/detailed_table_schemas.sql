-- =================================
-- DETAILED TABLE SCHEMAS
-- =================================

-- 1. Complete health_metrics table structure
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'health_metrics'
ORDER BY ordinal_position;

-- 2. Complete activities table structure  
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'activities'
ORDER BY ordinal_position;

-- 3. Complete days table structure
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'days'
ORDER BY ordinal_position;

-- 4. Complete users table structure
SELECT 
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default,
    ordinal_position
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'users'
ORDER BY ordinal_position;

-- 5. Sample data from health_metrics to see what exists
SELECT * FROM health_metrics LIMIT 3;

-- 6. Sample data from activities to see structure
SELECT * FROM activities LIMIT 3;
